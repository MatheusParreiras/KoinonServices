<?php

require_once __DIR__ . "/Conexao.php";
require_once __DIR__ . "/../dto/EncomendaDTO.php";

class EncomendaDAO
{
    private PDO $conexao;

    public function __construct()
    {
        $this->conexao = Conexao::conectar();
    }

    /*
     * ==========================================================
     * LISTAR ENCOMENDAS
     * ==========================================================
     */

    public function listar(): array
    {
        $sql = "
            SELECT
                e.*,
                u.identificacao AS unidade_identificacao,
                morador.nome AS usuario_nome
            FROM Encomenda e
            INNER JOIN Unidade u
                ON u.id = e.unidade_id
            LEFT JOIN Usuario morador
                ON morador.id = e.usuario_recebedor_id
            ORDER BY e.data_recebimento DESC
        ";

        $stmt = $this->conexao->prepare($sql);
        $stmt->execute();

        $resultados = [];

        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $linha) {
            $resultados[] = $this->montarDTO($linha);
        }

        return $resultados;
    }

    /*
     * ==========================================================
     * BUSCAR POR ID
     * ==========================================================
     */

    public function buscarPorId(int $id): ?EncomendaDTO
    {
        $sql = "
            SELECT
                e.*,
                u.identificacao AS unidade_identificacao,
                morador.nome AS usuario_nome
            FROM Encomenda e
            INNER JOIN Unidade u
                ON u.id = e.unidade_id
            LEFT JOIN Usuario morador
                ON morador.id = e.usuario_recebedor_id
            WHERE e.id = :id
            LIMIT 1
        ";

        $stmt = $this->conexao->prepare($sql);

        $stmt->bindValue(
            ":id",
            $id,
            PDO::PARAM_INT
        );

        $stmt->execute();

        $linha = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$linha) {
            return null;
        }

        return $this->montarDTO($linha);
    }

    /*
     * ==========================================================
     * CADASTRAR
     * ==========================================================
     */

    public function cadastrar(
        EncomendaDTO $encomenda
    ): bool {

        $sql = "
            INSERT INTO Encomenda (
                unidade_id,
                usuario_recebedor_id,
                descricao,
                foto_url,
                codigo_rastreio,
                data_recebimento,
                data_retirada,
                status
            )
            VALUES (
                :unidade_id,
                :usuario_recebedor_id,
                :descricao,
                :foto_url,
                :codigo_rastreio,
                :data_recebimento,
                NULL,
                :status
            )
        ";

        $stmt = $this->conexao->prepare($sql);

        $stmt->bindValue(
            ":unidade_id",
            $encomenda->getUnidadeId(),
            PDO::PARAM_INT
        );

        if (
            $encomenda->getUsuarioRecebedorId()
            !== null
        ) {
            $stmt->bindValue(
                ":usuario_recebedor_id",
                $encomenda->getUsuarioRecebedorId(),
                PDO::PARAM_INT
            );
        } else {
            $stmt->bindValue(
                ":usuario_recebedor_id",
                null,
                PDO::PARAM_NULL
            );
        }

        $stmt->bindValue(
            ":descricao",
            $encomenda->getDescricao(),
            PDO::PARAM_STR
        );

        $stmt->bindValue(
            ":foto_url",
            $encomenda->getFotoUrl(),
            PDO::PARAM_STR
        );

        $stmt->bindValue(
            ":codigo_rastreio",
            $encomenda->getCodigoRastreio(),
            PDO::PARAM_STR
        );

        $stmt->bindValue(
            ":data_recebimento",
            $encomenda->getDataRecebimento(),
            PDO::PARAM_STR
        );

        $stmt->bindValue(
            ":status",
            $encomenda->getStatus(),
            PDO::PARAM_STR
        );

        return $stmt->execute();
    }

    /*
     * ==========================================================
     * EDITAR
     * ==========================================================
     */

    public function editar(
        EncomendaDTO $encomenda
    ): bool {

        $sql = "
            UPDATE Encomenda
            SET
                unidade_id = :unidade_id,
                usuario_recebedor_id = :usuario_recebedor_id,
                descricao = :descricao,
                foto_url = :foto_url,
                codigo_rastreio = :codigo_rastreio
            WHERE id = :id
        ";

        $stmt = $this->conexao->prepare($sql);

        $stmt->bindValue(
            ":id",
            $encomenda->getId(),
            PDO::PARAM_INT
        );

        $stmt->bindValue(
            ":unidade_id",
            $encomenda->getUnidadeId(),
            PDO::PARAM_INT
        );

        if (
            $encomenda->getUsuarioRecebedorId()
            !== null
        ) {
            $stmt->bindValue(
                ":usuario_recebedor_id",
                $encomenda->getUsuarioRecebedorId(),
                PDO::PARAM_INT
            );
        } else {
            $stmt->bindValue(
                ":usuario_recebedor_id",
                null,
                PDO::PARAM_NULL
            );
        }

        $stmt->bindValue(
            ":descricao",
            $encomenda->getDescricao(),
            PDO::PARAM_STR
        );

        $stmt->bindValue(
            ":foto_url",
            $encomenda->getFotoUrl(),
            PDO::PARAM_STR
        );

        $stmt->bindValue(
            ":codigo_rastreio",
            $encomenda->getCodigoRastreio(),
            PDO::PARAM_STR
        );

        return $stmt->execute();
    }

    /*
     * ==========================================================
     * EXCLUIR
     * ==========================================================
     */

    public function excluir(int $id): bool
    {
        $sql = "
            DELETE FROM Encomenda
            WHERE id = :id
        ";

        $stmt = $this->conexao->prepare($sql);

        $stmt->bindValue(
            ":id",
            $id,
            PDO::PARAM_INT
        );

        return $stmt->execute();
    }

    /*
     * ==========================================================
     * ALTERAR STATUS
     * ==========================================================
     */

    public function alterarStatus(
        int $id,
        string $status
    ): bool {

        $statusPermitidos = [
            "Aguardando_Retirada",
            "Entregue",
            "Devolvido"
        ];

        if (
            !in_array(
                $status,
                $statusPermitidos,
                true
            )
        ) {
            return false;
        }

        if ($status === "Entregue") {
            return $this->marcarEntregue($id);
        }

        if ($status === "Aguardando_Retirada") {

            $sql = "
                UPDATE Encomenda
                SET
                    status = 'Aguardando_Retirada',
                    data_retirada = NULL
                WHERE id = :id
            ";

            $stmt = $this->conexao->prepare($sql);

            $stmt->bindValue(
                ":id",
                $id,
                PDO::PARAM_INT
            );

            return $stmt->execute();
        }

        if ($status === "Devolvido") {

            $sql = "
                UPDATE Encomenda
                SET
                    status = 'Devolvido',
                    data_retirada = NULL
                WHERE id = :id
            ";

            $stmt = $this->conexao->prepare($sql);

            $stmt->bindValue(
                ":id",
                $id,
                PDO::PARAM_INT
            );

            return $stmt->execute();
        }

        return false;
    }

    /*
     * ==========================================================
     * MARCAR COMO ENTREGUE
     * ==========================================================
     *
     * O usuario_recebedor_id continua sendo o MORADOR
     * destinatário da encomenda.
     *
     * A portaria apenas confirma a retirada.
     */

    public function marcarEntregue(
        int $id
    ): bool {

        $sql = "
            UPDATE Encomenda
            SET
                status = 'Entregue',
                data_retirada = NOW()
            WHERE
                id = :id
                AND status = 'Aguardando_Retirada'
        ";

        $stmt = $this->conexao->prepare($sql);

        $stmt->bindValue(
            ":id",
            $id,
            PDO::PARAM_INT
        );

        $stmt->execute();

        return $stmt->rowCount() > 0;
    }

    /*
     * ==========================================================
     * REABRIR
     * ==========================================================
     */

    public function reabrir(
        int $id
    ): bool {

        $sql = "
            UPDATE Encomenda
            SET
                status = 'Aguardando_Retirada',
                data_retirada = NULL
            WHERE id = :id
        ";

        $stmt = $this->conexao->prepare($sql);

        $stmt->bindValue(
            ":id",
            $id,
            PDO::PARAM_INT
        );

        return $stmt->execute();
    }

    /*
     * ==========================================================
     * LISTAR UNIDADES
     * ==========================================================
     */

    public function listarUnidades(): array
    {
        $sql = "
            SELECT
                id,
                identificacao
            FROM Unidade
            ORDER BY identificacao
        ";

        $stmt = $this->conexao->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );
    }

    /*
     * ==========================================================
     * LISTAR MORADORES POR UNIDADE
     * ==========================================================
     */

    public function listarMoradoresPorUnidade(
        int $unidadeId
    ): array {

        $sql = "
            SELECT
                id,
                nome,
                cpf,
                email
            FROM Usuario
            WHERE
                unidade_id = :unidade_id
                AND perfil = 'Morador'
                AND ativo = 1
            ORDER BY nome
        ";

        $stmt = $this->conexao->prepare($sql);

        $stmt->bindValue(
            ":unidade_id",
            $unidadeId,
            PDO::PARAM_INT
        );

        $stmt->execute();

        return $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );
    }

    /*
     * ==========================================================
     * MONTAR DTO
     * ==========================================================
     */

    private function montarDTO(
        array $linha
    ): EncomendaDTO {

        $dto = new EncomendaDTO();

        $dto->setId(
            isset($linha["id"])
                ? (int) $linha["id"]
                : null
        );

        $dto->setUnidadeId(
            isset($linha["unidade_id"])
                ? (int) $linha["unidade_id"]
                : null
        );

        $dto->setUsuarioRecebedorId(
            isset($linha["usuario_recebedor_id"])
                && $linha["usuario_recebedor_id"] !== null
                ? (int) $linha["usuario_recebedor_id"]
                : null
        );

        $dto->setDescricao(
            $linha["descricao"] ?? null
        );

        $dto->setFotoUrl(
            $linha["foto_url"] ?? null
        );

        $dto->setCodigoRastreio(
            $linha["codigo_rastreio"] ?? null
        );

        $dto->setDataRecebimento(
            $linha["data_recebimento"] ?? null
        );

        $dto->setDataRetirada(
            $linha["data_retirada"] ?? null
        );

        $dto->setStatus(
            $linha["status"]
                ?? "Aguardando_Retirada"
        );

        $dto->setUnidadeIdentificacao(
            $linha["unidade_identificacao"]
                ?? null
        );

        $dto->setUsuarioNome(
            $linha["usuario_nome"]
                ?? null
        );

        return $dto;
    }
}