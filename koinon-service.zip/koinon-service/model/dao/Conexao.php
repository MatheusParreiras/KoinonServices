<?php

class Conexao
{
    private static ?PDO $conexao = null;

    public static function conectar(): PDO
    {
        /*
         * ==========================================================
         * FUSO HORÁRIO DO SISTEMA
         * ==========================================================
         *
         * Brasília = America/Sao_Paulo
         * UTC-3
         */
        date_default_timezone_set("America/Sao_Paulo");

        /*
         * ==========================================================
         * DADOS DO BANCO
         * ==========================================================
         */

        $host = "127.0.0.1";
        $banco = "koinon_service";
        $usuario = "root";
        $senha = "";

        /*
         * ==========================================================
         * CRIA A CONEXÃO APENAS UMA VEZ
         * ==========================================================
         */

        if (self::$conexao === null) {

            $dsn =
                "mysql:"
                . "host=" . $host
                . ";dbname=" . $banco
                . ";charset=utf8mb4";

            try {

                self::$conexao = new PDO(
                    $dsn,
                    $usuario,
                    $senha,
                    [
                        PDO::ATTR_ERRMODE =>
                            PDO::ERRMODE_EXCEPTION,

                        PDO::ATTR_DEFAULT_FETCH_MODE =>
                            PDO::FETCH_ASSOC,

                        PDO::ATTR_EMULATE_PREPARES =>
                            false
                    ]
                );

                /*
                 * ==================================================
                 * CONFIGURA O MYSQL PARA O HORÁRIO DE BRASÍLIA
                 * ==================================================
                 *
                 * Isso é importante porque o banco utiliza
                 * CURRENT_TIMESTAMP e NOW().
                 */

                self::$conexao->exec(
                    "SET time_zone = '-03:00'"
                );

                // Garante apenas colunas novas dentro das tabelas existentes.
                // Nenhuma tabela nova é criada. Isso evita que o primeiro acesso
                // quebre quando o banco do XAMPP ainda estiver na versão antiga.
                self::garantirEstruturaTcc(self::$conexao);
                self::garantirAdministradorInicial(self::$conexao);

            } catch (PDOException $e) {

                die(
                    "Erro ao conectar ao banco de dados: "
                    . $e->getMessage()
                );
            }
        }

        return self::$conexao;
    }

    private static function colunaExiste(PDO $pdo, string $tabela, string $coluna): bool
    {
        $stmt = $pdo->prepare(
            "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = :tabela AND COLUMN_NAME = :coluna"
        );
        $stmt->execute([
            ':tabela' => $tabela,
            ':coluna' => $coluna,
        ]);
        return (int)$stmt->fetchColumn() > 0;
    }

    private static function garantirEstruturaTcc(PDO $pdo): void
    {
        $alteracoes = [
            'telefone' => "ALTER TABLE Usuario ADD COLUMN telefone VARCHAR(20) NULL AFTER email",
            'senha_definida' => "ALTER TABLE Usuario ADD COLUMN senha_definida TINYINT(1) NOT NULL DEFAULT 1 AFTER senha_hash",
            'primeiro_acesso' => "ALTER TABLE Usuario ADD COLUMN primeiro_acesso TINYINT(1) NOT NULL DEFAULT 0 AFTER senha_definida",
            'termo_lgpd' => "ALTER TABLE Usuario ADD COLUMN termo_lgpd TINYINT(1) NOT NULL DEFAULT 0 AFTER primeiro_acesso",
            'data_aceite_lgpd' => "ALTER TABLE Usuario ADD COLUMN data_aceite_lgpd DATETIME NULL AFTER termo_lgpd",
        ];

        foreach ($alteracoes as $coluna => $sql) {
            if (!self::colunaExiste($pdo, 'Usuario', $coluna)) {
                $pdo->exec($sql);
            }
        }
    }

    private static function garantirAdministradorInicial(PDO $pdo): void
    {
        $stmt = $pdo->prepare(
            "SELECT id FROM Usuario WHERE cpf = :cpf OR LOWER(email) = :email LIMIT 1"
        );
        $stmt->execute([
            ':cpf' => '01234567890',
            ':email' => 'admin@koinon.com',
        ]);

        if ($stmt->fetchColumn()) {
            return;
        }

        $hash = password_hash(bin2hex(random_bytes(24)), PASSWORD_DEFAULT);
        $insert = $pdo->prepare(
            "INSERT INTO Usuario
             (unidade_id, nome, cpf, email, telefone, senha_hash, senha_definida, primeiro_acesso, perfil, termo_lgpd, data_aceite_lgpd, ativo)
             VALUES (NULL, 'Administrador', '01234567890', 'admin@koinon.com', NULL, :hash, 0, 1, 'Administrador', 0, NULL, 1)"
        );
        $insert->execute([':hash' => $hash]);
    }
}