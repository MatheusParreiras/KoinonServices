<?php

class ReservaDTO
{
    private ?int $id = null;
    private ?int $usuario_id = null;
    private ?int $local_reserva_id = null;
    private ?string $usuario_nome = null;

    private string $espaco_nome = "";
    private int $quantidade_pessoas = 1;

    private ?string $data_inicio = null;
    private ?string $data_fim = null;

    private string $status = "Pendente";
    private float $valor_taxa = 0.00;

    /*
     * Status financeiro da reserva.
     *
     * Valores esperados:
     * - null
     * - Pendente
     * - Pago
     * - Vencido
     * - Cancelado
     */
    private ?string $pagamento_status = null;

    private ?string $created_at = null;


    public function getId(): ?int
    {
        return $this->id;
    }

    public function setId(?int $id): void
    {
        $this->id = $id;
    }


    public function getUsuarioId(): ?int
    {
        return $this->usuario_id;
    }

    public function setUsuarioId(?int $usuario_id): void
    {
        $this->usuario_id = $usuario_id;
    }


    public function getUsuarioNome(): ?string
    {
        return $this->usuario_nome;
    }

    public function setUsuarioNome(?string $usuario_nome): void
    {
        $this->usuario_nome = $usuario_nome;
    }


    public function getLocalReservaId(): ?int
    {
        return $this->local_reserva_id;
    }

    public function setLocalReservaId(?int $local_reserva_id): void
    {
        $this->local_reserva_id = $local_reserva_id;
    }


    public function getEspacoNome(): string
    {
        return $this->espaco_nome;
    }

    public function setEspacoNome(string $espaco_nome): void
    {
        $this->espaco_nome = $espaco_nome;
    }


    public function getQuantidadePessoas(): int
    {
        return $this->quantidade_pessoas;
    }

    public function setQuantidadePessoas(int $quantidade_pessoas): void
    {
        $this->quantidade_pessoas = $quantidade_pessoas;
    }


    public function getDataInicio(): ?string
    {
        return $this->data_inicio;
    }

    public function setDataInicio(?string $data_inicio): void
    {
        $this->data_inicio = $data_inicio;
    }


    public function getDataFim(): ?string
    {
        return $this->data_fim;
    }

    public function setDataFim(?string $data_fim): void
    {
        $this->data_fim = $data_fim;
    }


    public function getStatus(): string
    {
        return $this->status;
    }

    public function setStatus(string $status): void
    {
        $this->status = $status;
    }


    public function getValorTaxa(): float
    {
        return $this->valor_taxa;
    }

    public function setValorTaxa(float $valor_taxa): void
    {
        $this->valor_taxa = $valor_taxa;
    }


    public function getPagamentoStatus(): ?string
    {
        return $this->pagamento_status;
    }

    public function setPagamentoStatus(?string $pagamento_status): void
    {
        $this->pagamento_status = $pagamento_status;
    }


    public function getCreatedAt(): ?string
    {
        return $this->created_at;
    }

    public function setCreatedAt(?string $created_at): void
    {
        $this->created_at = $created_at;
    }
}