<?php
/*
 * Koinon Service - Canais de recuperação de senha.
 * Nunca publique chaves reais no Git/ZIP do TCC. Prefira variáveis de ambiente.
 */
return [
    "base_url" => getenv("KOINON_BASE_URL") ?: "",
    "email" => [
        "provedor" => getenv("KOINON_EMAIL_PROVIDER") ?: "mail",
        "resend_api_key" => getenv("RESEND_API_KEY") ?: "",
        "remetente_nome" => getenv("KOINON_EMAIL_FROM_NAME") ?: "Koinon Service",
        "remetente_email" => getenv("KOINON_EMAIL_FROM") ?: "onboarding@resend.dev",
    ],
    "whatsapp" => [
        "habilitado" => filter_var(getenv("KOINON_WHATSAPP_ENABLED") ?: "0", FILTER_VALIDATE_BOOL),
        "phone_number_id" => getenv("WHATSAPP_PHONE_NUMBER_ID") ?: "",
        "access_token" => getenv("WHATSAPP_ACCESS_TOKEN") ?: "",
        "graph_version" => getenv("WHATSAPP_GRAPH_VERSION") ?: "v23.0",
        "template_name" => getenv("WHATSAPP_TEMPLATE_NAME") ?: "koinon_redefinicao_senha",
        "template_language" => getenv("WHATSAPP_TEMPLATE_LANGUAGE") ?: "pt_BR",
    ],
];
