# Koinon Service — Notas da V10

## Ajustes desta versão
- Encomendas: removido o botão Sair do cabeçalho interno; permanecem sino e troca de tema.
- Portaria: removido o botão Sair e o bloco de nome/perfil do cabeçalho interno; permanecem sino e troca de tema.
- LGPD/registros: removidos Dashboard e Sair do cabeçalho; o retorno ao Dashboard continua no conteúdo da página.
- Área do Morador: removida a grade superior de atalhos duplicados; os acessos ficam nos próprios módulos.
- Área do Morador: removido o botão duplicado de autorizações do card-resumo; o gerenciamento completo permanece no módulo de Autorizações.
- Notificações: reforço de contraste no tema escuro para títulos, mensagens, datas e botões.
- Vagas: reforço de contraste do indicador de vagas.
- Banco de dados: mantido o `database.sql` da V9, sem alteração estrutural nesta correção de interface.
- Documentação e diagramas: revisados para refletir a V10 e o esquema atual do banco.

## Observação
As regras de negócio da V9 para Síndico, financeiro e locais de reserva foram preservadas.
