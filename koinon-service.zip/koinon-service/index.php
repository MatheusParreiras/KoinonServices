<?php

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

$usuarioLogado = !empty($_SESSION["usuario_id"]);
$nomeUsuario = $_SESSION["usuario_nome"] ?? null;
$perfilUsuario = $_SESSION["usuario_perfil"] ?? null;

$contatoMensagem = null;
$contatoTipo = 'info';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['acao'] ?? '') === 'contato') {
    require_once __DIR__ . '/service/EmailService.php';

    $nome = trim($_POST['contato_nome'] ?? '');
    $email = trim($_POST['contato_email'] ?? '');
    $telefone = trim($_POST['contato_telefone'] ?? '');
    $empresa = trim($_POST['contato_empresa'] ?? '');
    $mensagem = trim($_POST['contato_mensagem'] ?? '');

    if ($nome === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || $mensagem === '') {
        $contatoMensagem = 'Preencha nome, e-mail válido e a mensagem para enviar o contato.';
        $contatoTipo = 'danger';
    } else {
        $destino = getenv('KOINON_CONTATO_EMAIL') ?: 'contato@koinonservice.com';
        $corpo = "Novo contato comercial - Koinon Service\n\n"
            . "Nome: {$nome}\n"
            . "E-mail: {$email}\n"
            . "Telefone: {$telefone}\n"
            . "Condomínio/empresa: {$empresa}\n\n"
            . "Mensagem:\n{$mensagem}";

        $emailService = new EmailService();
        $enviado = $emailService->enviar($destino, 'Novo contato comercial - Koinon Service', $corpo);

        if ($enviado) {
            $contatoMensagem = 'Mensagem enviada com sucesso. Entraremos em contato pelos dados informados.';
            $contatoTipo = 'success';
        } else {
            $contatoMensagem = 'Não foi possível enviar o e-mail pelo servidor atual. Configure o SMTP/mail() do XAMPP e tente novamente.';
            $contatoTipo = 'warning';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Koinon Service - Gestão de Condomínios</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <style>

        body {
            background-color: var(--k-bg);
            color: var(--k-text);
        }

        .navbar {
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
        }

        .navbar-brand {
            font-weight: 700;
            font-size: 1.4rem;
        }

        .hero {
            min-height: 560px;
            display: flex;
            align-items: center;
            background:
                linear-gradient(
                    135deg,
                    #0d6efd 0%,
                    #084298 100%
                );
            color: white;
        }

        .hero h1 {
            font-size: 3rem;
            font-weight: 700;
        }

        .hero p {
            font-size: 1.15rem;
            line-height: 1.7;
        }

        .hero-card {
            background-color: rgba(255, 255, 255, 0.12);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 20px;
            padding: 35px;
            backdrop-filter: blur(8px);
        }

        .section-title {
            font-weight: 700;
            margin-bottom: 10px;
        }

        .section-subtitle {
            color: #6c757d;
            margin-bottom: 40px;
        }

        .service-card {
            height: 100%;
            border: none;
            border-radius: 16px;
            box-shadow: 0 5px 18px rgba(0, 0, 0, 0.08);
            transition: 0.2s;
        }

        .service-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.12);
        }

        .service-icon {
            width: 60px;
            height: 60px;
            border-radius: 15px;
            background-color: #e7f0ff;
            color: #0d6efd;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.7rem;
            margin-bottom: 20px;
        }

        .profile-card {
            border: none;
            border-radius: 18px;
            box-shadow: 0 5px 18px rgba(0, 0, 0, 0.08);
            height: 100%;
        }

        .profile-card ul {
            padding-left: 20px;
        }

        .profile-card li {
            margin-bottom: 8px;
        }

        .about-section {
            background-color: var(--k-surface);
        }

        .cta-section {
            background: linear-gradient(135deg, #1d4ed8, #4f46e5 55%, #7c3aed);
            color: white;
        }

        footer {
            background-color: #212529;
            color: #adb5bd;
        }

        footer strong {
            color: white;
        }

        @media (max-width: 768px) {

            .hero {
                min-height: auto;
                padding: 80px 0;
            }

            .hero h1 {
                font-size: 2.2rem;
            }

            .hero-card {
                margin-top: 35px;
            }

        }

    </style>


    <link rel="stylesheet" href="assets/css/estilo.css">

</head>

<body>

<!-- ========================================================= -->
<!-- MENU -->
<!-- ========================================================= -->

<nav class="navbar navbar-expand-lg bg-white sticky-top">

    <div class="container">

        <a class="navbar-brand text-primary d-flex align-items-center gap-2" href="index.php">
            <img src="assets/img/logo-placeholder.svg" class="koinon-logo-small" alt="Koinon Service">
            <span>Koinon Service</span>
        </a>

        <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#menuPrincipal"
            aria-controls="menuPrincipal"
            aria-expanded="false"
            aria-label="Abrir menu"
        >
            <span class="navbar-toggler-icon"></span>
        </button>

        <div
            class="collapse navbar-collapse"
            id="menuPrincipal"
        >

            <ul class="navbar-nav ms-auto align-items-lg-center">

                <li class="nav-item">
                    <a
                        class="nav-link"
                        href="#sobre"
                    >
                        Sobre o sistema
                    </a>
                </li>

                <li class="nav-item">
                    <a
                        class="nav-link"
                        href="#servicos"
                    >
                        Serviços
                    </a>
                </li>

                <li class="nav-item">
                    <a
                        class="nav-link"
                        href="#usuarios"
                    >
                        Usuários
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="#contato">Fale conosco</a>
                </li>

                <?php if ($usuarioLogado): ?>

                    <li class="nav-item ms-lg-2 mt-2 mt-lg-0">

                        <a
                            class="btn btn-primary"
                            href="view/dashboard.php"
                        >
                            Acessar sistema
                        </a>

                    </li>

                <?php else: ?>

                    <li class="nav-item ms-lg-2 mt-2 mt-lg-0">

                        <a
                            class="btn btn-outline-primary"
                            href="view/login.php?tipo=morador"
                        >
                            Entrar
                        </a>

                    </li>

                <?php endif; ?>

            </ul>

        </div>

    </div>

</nav>


<!-- ========================================================= -->
<!-- HERO -->
<!-- ========================================================= -->

<section class="hero">

    <div class="container">

        <div class="row align-items-center">

            <div class="col-lg-7">

                <span class="badge bg-light text-primary mb-3 px-3 py-2">
                    Gestão inteligente de condomínios
                </span>

                <h1>
                    Simplifique a gestão do seu condomínio.
                </h1>

                <p class="mt-4">

                    O Koinon Service reúne em um único sistema
                    recursos para administração, moradores,
                    portaria e gestão do condomínio.

                </p>

                <div class="mt-4 d-flex flex-wrap gap-2">

                    <?php if ($usuarioLogado): ?>

                        <a
                            href="view/dashboard.php"
                            class="btn btn-light btn-lg"
                        >
                            Acessar meu sistema
                        </a>

                    <?php else: ?>

                        <a
                            href="view/login.php?tipo=morador"
                            class="btn btn-light btn-lg"
                        >
                            Entrar como Morador
                        </a>

                        <a
                            href="view/login.php?tipo=funcionario"
                            class="btn btn-outline-light btn-lg"
                        >
                            Entrar como Funcionário
                        </a>

                    <?php endif; ?>

                </div>

            </div>


            <div class="col-lg-5">

                <div class="hero-card">

                    <h3 class="fw-bold mb-4">
                        🏢 Koinon Service
                    </h3>

                    <p class="mb-4">
                        Uma plataforma para organizar as principais
                        atividades de um condomínio de forma simples,
                        centralizada e segura.
                    </p>

                    <div class="row g-3">

                        <div class="col-6">

                            <div class="bg-white bg-opacity-10 rounded p-3">

                                <h4 class="fw-bold mb-1">
                                    🔐
                                </h4>

                                <small>
                                    Controle de acesso
                                </small>

                            </div>

                        </div>

                        <div class="col-6">

                            <div class="bg-white bg-opacity-10 rounded p-3">

                                <h4 class="fw-bold mb-1">
                                    💰
                                </h4>

                                <small>
                                    Gestão financeira
                                </small>

                            </div>

                        </div>

                        <div class="col-6">

                            <div class="bg-white bg-opacity-10 rounded p-3">

                                <h4 class="fw-bold mb-1">
                                    📦
                                </h4>

                                <small>
                                    Encomendas
                                </small>

                            </div>

                        </div>

                        <div class="col-6">

                            <div class="bg-white bg-opacity-10 rounded p-3">

                                <h4 class="fw-bold mb-1">
                                    📅
                                </h4>

                                <small>
                                    Reservas
                                </small>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</section>


<!-- ========================================================= -->
<!-- SOBRE -->
<!-- ========================================================= -->

<section
    id="sobre"
    class="about-section py-5"
>

    <div class="container py-4">

        <div class="row align-items-center">

            <div class="col-lg-6">

                <h2 class="section-title">
                    Por que utilizar o Koinon Service?
                </h2>

                <p class="section-subtitle">
                    Mais organização para a administração e
                    mais praticidade para os moradores.
                </p>

                <p>
                    O Koinon Service foi desenvolvido para
                    centralizar as principais atividades de um
                    condomínio em uma única plataforma.
                </p>

                <p>
                    Com o sistema, informações que normalmente
                    ficam espalhadas em planilhas, mensagens
                    e controles manuais podem ser organizadas
                    em um ambiente único.
                </p>

                <p>
                    Isso facilita o acompanhamento das atividades
                    do condomínio, melhora a comunicação e ajuda
                    na organização da rotina dos moradores,
                    funcionários e administração.
                </p>

            </div>


            <div class="col-lg-6">

                <div class="row g-3">

                    <div class="col-md-6">

                        <div class="service-card card p-4">

                            <div class="service-icon">
                                🔐
                            </div>

                            <h5 class="fw-bold">
                                Mais segurança
                            </h5>

                            <p class="text-muted mb-0">
                                Controle de visitantes,
                                autorizações e registros
                                de acesso.
                            </p>

                        </div>

                    </div>


                    <div class="col-md-6">

                        <div class="service-card card p-4">

                            <div class="service-icon">
                                📊
                            </div>

                            <h5 class="fw-bold">
                                Mais organização
                            </h5>

                            <p class="text-muted mb-0">
                                Centralização das informações
                                do condomínio.
                            </p>

                        </div>

                    </div>


                    <div class="col-md-6">

                        <div class="service-card card p-4">

                            <div class="service-icon">
                                ⏱️
                            </div>

                            <h5 class="fw-bold">
                                Mais praticidade
                            </h5>

                            <p class="text-muted mb-0">
                                Processos mais simples para
                                moradores e funcionários.
                            </p>

                        </div>

                    </div>


                    <div class="col-md-6">

                        <div class="service-card card p-4">

                            <div class="service-icon">
                                📱
                            </div>

                            <h5 class="fw-bold">
                                Acesso centralizado
                            </h5>

                            <p class="text-muted mb-0">
                                Informações disponíveis em
                                um único sistema.
                            </p>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</section>


<!-- ========================================================= -->
<!-- SERVIÇOS -->
<!-- ========================================================= -->

<section
    id="servicos"
    class="py-5"
>

    <div class="container py-4">

        <div class="text-center">

            <h2 class="section-title">
                Recursos do Koinon Service
            </h2>

            <p class="section-subtitle">
                Recursos desenvolvidos para facilitar a gestão
                do condomínio.
            </p>

        </div>


        <div class="row g-4">

            <div class="col-md-6 col-lg-4">

                <div class="service-card card p-4">

                    <div class="service-icon">
                        👥
                    </div>

                    <h5 class="fw-bold">
                        Gestão de moradores
                    </h5>

                    <p class="text-muted">
                        Cadastro e gerenciamento dos usuários
                        e moradores do condomínio.
                    </p>

                </div>

            </div>


            <div class="col-md-6 col-lg-4">

                <div class="service-card card p-4">

                    <div class="service-icon">
                        🚗
                    </div>

                    <h5 class="fw-bold">
                        Veículos
                    </h5>

                    <p class="text-muted">
                        Cadastro e organização dos veículos
                        vinculados aos moradores.
                    </p>

                </div>

            </div>


            <div class="col-md-6 col-lg-4">

                <div class="service-card card p-4">

                    <div class="service-icon">
                        📅
                    </div>

                    <h5 class="fw-bold">
                        Reservas
                    </h5>

                    <p class="text-muted">
                        Controle de reservas dos espaços
                        disponíveis no condomínio.
                    </p>

                </div>

            </div>


            <div class="col-md-6 col-lg-4">

                <div class="service-card card p-4">

                    <div class="service-icon">
                        📦
                    </div>

                    <h5 class="fw-bold">
                        Encomendas
                    </h5>

                    <p class="text-muted">
                        Controle de recebimento e retirada
                        de encomendas.
                    </p>

                </div>

            </div>


            <div class="col-md-6 col-lg-4">

                <div class="service-card card p-4">

                    <div class="service-icon">
                        🔐
                    </div>

                    <h5 class="fw-bold">
                        Portaria
                    </h5>

                    <p class="text-muted">
                        Controle de visitantes, autorizações,
                        QR Codes e registros de acesso.
                    </p>

                </div>

            </div>


            <div class="col-md-6 col-lg-4">

                <div class="service-card card p-4">

                    <div class="service-icon">
                        💰
                    </div>

                    <h5 class="fw-bold">
                        Financeiro
                    </h5>

                    <p class="text-muted">
                        Organização das cobranças e
                        acompanhamento financeiro.
                    </p>

                </div>

            </div>


            <div class="col-md-6 col-lg-4">

                <div class="service-card card p-4">

                    <div class="service-icon">
                        ⚠️
                    </div>

                    <h5 class="fw-bold">
                        Ocorrências
                    </h5>

                    <p class="text-muted">
                        Registro e acompanhamento de
                        ocorrências do condomínio.
                    </p>

                </div>

            </div>


            <div class="col-md-6 col-lg-4">

                <div class="service-card card p-4">

                    <div class="service-icon">
                        📢
                    </div>

                    <h5 class="fw-bold">
                        Comunicação
                    </h5>

                    <p class="text-muted">
                        Publicações e comunicação entre
                        moradores e administração.
                    </p>

                </div>

            </div>


            <div class="col-md-6 col-lg-4">

                <div class="service-card card p-4">

                    <div class="service-icon">
                        📄
                    </div>

                    <h5 class="fw-bold">
                        Documentos
                    </h5>

                    <p class="text-muted">
                        Organização dos documentos importantes
                        do condomínio.
                    </p>

                </div>

            </div>

        </div>

    </div>

</section>


<!-- ========================================================= -->
<!-- USUÁRIOS -->
<!-- ========================================================= -->

<section
    id="usuarios"
    class="about-section py-5"
>

    <div class="container py-4">

        <div class="text-center">

            <h2 class="section-title">
                Acesso para cada perfil
            </h2>

            <p class="section-subtitle">
                Cada usuário possui acesso aos recursos
                necessários para sua função.
            </p>

        </div>


        <div class="row g-4">

            <!-- MORADOR -->

            <div class="col-md-6 col-lg-3">

                <div class="profile-card card p-4">

                    <div class="service-icon">
                        🏠
                    </div>

                    <h5 class="fw-bold">
                        Morador
                    </h5>

                    <p class="text-muted">
                        Acesso aos recursos relacionados
                        à sua unidade.
                    </p>

                    <ul class="text-muted">

                        <li>Reservas</li>

                        <li>Veículos</li>

                        <li>Encomendas</li>

                        <li>Ocorrências</li>

                        <li>Visitantes</li>

                        <li>Financeiro</li>

                    </ul>

                </div>

            </div>


            <!-- PORTEIRO -->

            <div class="col-md-6 col-lg-3">

                <div class="profile-card card p-4">

                    <div class="service-icon">
                        🛡️
                    </div>

                    <h5 class="fw-bold">
                        Porteiro
                    </h5>

                    <p class="text-muted">
                        Recursos relacionados ao controle
                        de acesso do condomínio.
                    </p>

                    <ul class="text-muted">

                        <li>Portaria</li>

                        <li>Visitantes</li>

                        <li>QR Code</li>

                        <li>Registros de acesso</li>

                        <li>Encomendas</li>

                    </ul>

                </div>

            </div>


            <!-- SÍNDICO -->

            <div class="col-md-6 col-lg-3">

                <div class="profile-card card p-4">

                    <div class="service-icon">
                        👔
                    </div>

                    <h5 class="fw-bold">
                        Síndico
                    </h5>

                    <p class="text-muted">
                        Recursos para acompanhamento
                        e gestão do condomínio.
                    </p>

                    <ul class="text-muted">

                        <li>Reservas</li>

                        <li>Ocorrências</li>

                        <li>Portaria</li>

                        <li>Publicações</li>

                        <li>Documentos</li>

                    </ul>

                </div>

            </div>


            <!-- ADMINISTRADOR -->

            <div class="col-md-6 col-lg-3">

                <div class="profile-card card p-4">

                    <div class="service-icon">
                        ⚙️
                    </div>

                    <h5 class="fw-bold">
                        Administrador
                    </h5>

                    <p class="text-muted">
                        Gerenciamento das principais
                        funcionalidades do condomínio.
                    </p>

                    <ul class="text-muted">

                        <li>Usuários</li>

                        <li>Unidades</li>

                        <li>Financeiro</li>

                        <li>Portaria</li>

                        <li>Relatórios</li>

                    </ul>

                </div>

            </div>

        </div>

    </div>

</section>


<!-- ========================================================= -->
<!-- CTA -->
<!-- ========================================================= -->

<section class="cta-section py-5">

    <div class="container text-center py-4">

        <h2 class="fw-bold">
            Pronto para utilizar o Koinon Service?
        </h2>

        <p class="mt-3 mb-4">
            Acesse o sistema de acordo com seu perfil.
        </p>


        <?php if ($usuarioLogado): ?>

            <a
                href="view/dashboard.php"
                class="btn btn-light btn-lg"
            >
                Acessar sistema
            </a>

        <?php else: ?>

            <div class="d-flex justify-content-center flex-wrap gap-2">

                <a
                    href="view/login.php?tipo=morador"
                    class="btn btn-light btn-lg"
                >
                    Entrar como Morador
                </a>

                <a
                    href="view/login.php?tipo=funcionario"
                    class="btn btn-outline-light btn-lg"
                >
                    Entrar como Funcionário
                </a>

            </div>

        <?php endif; ?>

    </div>

</section>


<!-- ========================================================= -->
<!-- FALE CONOSCO -->
<!-- ========================================================= -->

<section id="contato" class="py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-9">
                <div class="card border-0 shadow-sm p-4 p-lg-5">
                    <div class="row g-4 align-items-center">
                        <div class="col-lg-5">
                            <span class="badge text-bg-primary mb-3">Fale conosco</span>
                            <h2 class="section-title">Quer conhecer o Koinon Service?</h2>
                            <p class="text-muted mb-0">Preencha seus dados e conte um pouco sobre o condomínio ou serviço que você procura. A equipe poderá entrar em contato para apresentar a solução.</p>
                        </div>
                        <div class="col-lg-7">
                            <?php if ($contatoMensagem): ?>
                                <div class="alert alert-<?= htmlspecialchars($contatoTipo) ?>"><?= htmlspecialchars($contatoMensagem) ?></div>
                            <?php endif; ?>
                            <form method="POST" action="index.php#contato" class="row g-3">
                                <input type="hidden" name="acao" value="contato">
                                <div class="col-md-6">
                                    <label class="form-label">Nome</label>
                                    <input type="text" name="contato_nome" class="form-control" maxlength="120" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">E-mail</label>
                                    <input type="email" name="contato_email" class="form-control" maxlength="150" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Telefone</label>
                                    <input type="text" name="contato_telefone" class="form-control" maxlength="30">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Condomínio/empresa</label>
                                    <input type="text" name="contato_empresa" class="form-control" maxlength="150">
                                </div>
                                <div class="col-12">
                                    <label class="form-label">Como podemos ajudar?</label>
                                    <textarea name="contato_mensagem" class="form-control" rows="4" maxlength="1500" required></textarea>
                                </div>
                                <div class="col-12 d-flex justify-content-between align-items-center gap-3 flex-wrap">
                                    <button class="btn btn-primary px-4" type="submit">Enviar contato</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ========================================================= -->
<!-- FOOTER -->
<!-- ========================================================= -->

<footer class="py-4">

    <div class="container">

        <div class="row align-items-center">

            <div class="col-md-6">

                <strong>
                    Koinon Service
                </strong>

                <div class="small mt-1">
                    Sistema de Gestão de Condomínios
                </div>

            </div>

            <div class="col-md-6 text-md-end mt-3 mt-md-0">

                <div class="small">
                    © <?= date("Y"); ?> Koinon Service
                </div>

                <div class="small">
                    Todos os direitos reservados.
                </div>

            </div>

        </div>

    </div>

</footer>


<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
></script>


<script src="assets/js/script.js"></script>

</body>

</html>