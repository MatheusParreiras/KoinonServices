# Koinon Service — V9

A V9 consolida as correções de permissões, temas, dashboard do Morador, encomendas e documentação. Consulte `NOTAS_VERSAO_FINAL_V9.md` e `DOCUMENTACAO_KOINON_V9.docx`.

# Koinon Service — versão final para apresentação do TCC

## O que foi atualizado

- Visual geral com identidade premium, cards, gradientes, sombras e melhor responsividade.
- Alternância entre tema claro e escuro com persistência no navegador.
- Login por CPF OU e-mail; o CPF continua sendo o documento de identificação do usuário.
- Primeiro acesso sem senha.
- Após o primeiro acesso, o usuário precisa aceitar a LGPD.
- O aceite da LGPD é gravado na tabela `Usuario`, nos campos `termo_lgpd` e `data_aceite_lgpd`.
- Depois do aceite, o usuário é direcionado para `view/definir_senha.php`.
- A senha é armazenada com `password_hash()` e passa a ser obrigatória nos próximos logins.
- Recuperação de senha com link temporário e uso único.
- Envio de link por e-mail usando `mail()` quando o servidor estiver configurado.
- Envio de WhatsApp preparado para a API oficial do WhatsApp Cloud/Meta.
- Sem API configurada, o sistema gera um link click-to-chat para a apresentação.
- Foi adicionada a coluna `telefone` na tabela `Usuario` para permitir o canal WhatsApp.
- O cadastro de usuário administrativo não define a senha do titular; a senha é criada pelo próprio usuário no primeiro acesso.
- Cadastro/edição de usuários passou a aceitar WhatsApp/telefone.
- Cadastro de veículos foi retirado da área do Morador.
- Gestão de veículos continua na área de gestão (Síndico/Administrador).
- Os campos exibidos como “Documento” relacionados a visitantes foram identificados como CPF, mantendo o nome técnico `documento` no banco para não criar tabela/estrutura desnecessária.
- Documentação em Word preenchida com conteúdo do Koinon Service e diagramas.

## Banco de dados

Não foi criada nenhuma tabela nova.

Execute `ATUALIZACAO_BANCO_TCC.sql` no phpMyAdmin caso esteja usando um banco criado a partir de uma versão anterior do projeto.

A atualização adiciona somente campos na tabela `Usuario`:

- `telefone`
- `senha_definida`
- `primeiro_acesso`

O `DATABASE.sql` da raiz também foi atualizado para representar a estrutura final.

## Teste do primeiro acesso

1. Crie/ative um usuário.
2. Garanta que `senha_definida = 0`, `primeiro_acesso = 1` e `termo_lgpd = 0`.
3. Entre em `view/login.php`.
4. Selecione Morador ou Funcionário.
5. Informe somente o CPF.
6. O sistema libera o primeiro acesso sem senha.
7. Aceite o termo LGPD.
8. O sistema registra data/hora do aceite no usuário.
9. A tela de definição de senha aparece.
10. Cadastre a senha.
11. Saia do sistema.
12. No próximo login, CPF + senha serão obrigatórios.

## E-mail

O envio pode usar `mail()` do PHP ou Resend API. Para Resend, configure `RESEND_API_KEY`, `KOINON_EMAIL_PROVIDER=resend`, remetente verificado e `KOINON_BASE_URL`.

Os dados do remetente ficam em `config_canais.php`.

## WhatsApp

Para envio automático, configure no arquivo `config_canais.php`:

- `habilitado = true`
- `phone_number_id`
- `access_token`
- `graph_version`

O telefone armazenado deve estar em formato internacional, por exemplo:

`5561999999999`

Sem credenciais da API, o sistema não inventa um envio automático: ele oferece um link oficial `wa.me` para o usuário abrir o WhatsApp e concluir o envio.

## Perfis

1. Administrador — superusuário/gestor do sistema.
2. Síndico — tomador de decisões e representante legal.
3. Porteiro — operação de portaria, segurança e acesso.
4. Morador — usuário final dos serviços.

## Estrutura importante

- `view/login.php` — autenticação por CPF.
- `view/lgpd.php` — aceite da LGPD.
- `view/definir_senha.php` — criação da senha no primeiro acesso.
- `view/esqueci_senha.php` — solicitação de recuperação.
- `view/redefinir_senha.php` — definição/redefinição por token.
- `service/PasswordLinkService.php` — geração e entrega do link.
- `config_canais.php` — configuração dos canais.
- `ATUALIZACAO_BANCO_TCC.sql` — atualização sem criação de tabelas.


## Administrador inicial

O `DATABASE.sql` e o script de atualização deixam o usuário `admin@koinon.com` / CPF `01234567890` ativo e em primeiro acesso. Não existe senha inicial: o fluxo é CPF/e-mail -> LGPD -> criação da senha -> acesso normal.

## API de e-mail Resend

Use variáveis de ambiente, sem gravar a chave no ZIP:
`KOINON_EMAIL_PROVIDER=resend`
`RESEND_API_KEY=re_xxx`
`KOINON_EMAIL_FROM=seu-remetente@seu-dominio`
`KOINON_EMAIL_FROM_NAME=Koinon Service`
`KOINON_BASE_URL=https://seu-dominio.com/koinon-service`

## WhatsApp Cloud API

Configure `KOINON_WHATSAPP_ENABLED=1`, `WHATSAPP_PHONE_NUMBER_ID`, `WHATSAPP_ACCESS_TOKEN`, `WHATSAPP_GRAPH_VERSION`, `WHATSAPP_TEMPLATE_NAME` e `WHATSAPP_TEMPLATE_LANGUAGE`. O template deve estar aprovado no WhatsApp Business e conter duas variáveis no corpo: nome e link.

## Atualização V3 — correções finais

- Morador não cadastra veículos; somente Administrador e Síndico.
- Financeiro administrativo liberado para Administrador e Síndico.
- Criada `view/lgpd_registros.php` para consulta dos aceites LGPD dos moradores.
- Aceite LGPD permanece em `Usuario.termo_lgpd` e `Usuario.data_aceite_lgpd`; nenhuma tabela nova foi criada.
- Corrigida referência inexistente `$veiculos` na área do Morador.
- Navbar padronizada: marca à esquerda e ações (notificações, tema e sair) à direita.
- Tema escuro reforçado para tabelas, badges, botões, cards e cores antigas do Bootstrap.
- Script opcional de atualização: `ATUALIZACAO_BANCO_TCC_V3.sql`.
