<?php

require_once __DIR__ . "/../../controller/PermissaoController.php";
require_once __DIR__ . "/../../controller/MoradorController.php";
require_once __DIR__ . "/../../controller/LocalReservaController.php";

PermissaoController::exigirMorador();

$usuarioId = (int) ($_SESSION["usuario_id"] ?? 0);

$controller = new MoradorController();
$localController = new LocalReservaController();

$locais = $localController->listarAtivos();

$erro = "";

$espacoNome = "";
$dataInicio = "";
$dataFim = "";
$quantidadePessoas = 1;

/*
 * Guarda as configurações de duração dos locais.
 *
 * IMPORTANTE:
 * Usamos somente os métodos de duração.
 * O getNome() continua sendo usado da mesma forma
 * que já foi testado e funcionando.
 */
$configuracoesLocais = [];

foreach ($locais as $local) {

    $nomeLocal = (string) $local->getNome();

    $duracaoMin = 60;
    $duracaoMax = 60;

    /*
     * Proteção para evitar que a tela desapareça
     * caso algum método não exista no DTO.
     */
    if (method_exists($local, "getDuracaoMinutosMinima")) {

        $duracaoMin =
            (int) $local->getDuracaoMinutosMinima();
    }

    if (method_exists($local, "getDuracaoMinutosMaxima")) {

        $duracaoMax =
            (int) $local->getDuracaoMinutosMaxima();
    }

    /*
     * Valores de segurança.
     */
    if ($duracaoMin <= 0) {
        $duracaoMin = 60;
    }

    if ($duracaoMax <= 0) {
        $duracaoMax = $duracaoMin;
    }

    /*
     * Caso o máximo esteja menor que o mínimo,
     * corrigimos apenas para a exibição.
     */
    if ($duracaoMax < $duracaoMin) {

        $temporario = $duracaoMin;

        $duracaoMin = $duracaoMax;
        $duracaoMax = $temporario;
    }

    $configuracoesLocais[$nomeLocal] = [
        "min" => $duracaoMin,
        "max" => $duracaoMax,
        "fotos" => method_exists($local, "getFotosArray") ? $local->getFotosArray() : []
    ];
}


if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $espacoNome =
        trim($_POST["espaco_nome"] ?? "");

    $dataInicio =
        trim($_POST["data_inicio"] ?? "");

    $dataFim =
        trim($_POST["data_fim"] ?? "");

    $quantidadePessoas =
        (int) ($_POST["quantidade_pessoas"] ?? 1);


    if ($espacoNome === "") {

        $erro =
            "Selecione um local para realizar a reserva.";

    } elseif ($dataInicio === "") {

        $erro =
            "Informe a data e o horário de início.";

    } elseif ($dataFim === "") {

        $erro =
            "Informe a duração e o horário de início para calcular o término da reserva.";

    } elseif ($quantidadePessoas < 1) {

        $erro =
            "Informe pelo menos 1 pessoa.";

    } else {

        $dataInicioMysql =
            str_replace("T", " ", $dataInicio);

        $dataFimMysql =
            str_replace("T", " ", $dataFim);


        if (strlen($dataInicioMysql) === 16) {

            $dataInicioMysql .= ":00";
        }

        if (strlen($dataFimMysql) === 16) {

            $dataFimMysql .= ":00";
        }


        try {

            /*
             * O backend continua sendo responsável
             * por validar:
             *
             * - capacidade
             * - duração mínima/máxima
             * - horários permitidos
             * - dias permitidos
             * - antecedência
             * - limite de reservas
             * - conflitos/overlap
             * - valor
             * - local ativo
             */

            $resultado =
                $controller->criarReserva(
                    $usuarioId,
                    $espacoNome,
                    $dataInicioMysql,
                    $dataFimMysql,
                    $quantidadePessoas
                );


            if ($resultado) {

                header(
                    "Location: index.php?reserva=sucesso"
                );

                exit;
            }


            $erro =
                $controller->getUltimoErroReserva();


            if ($erro === "") {

                $erro =
                    "Não foi possível realizar a reserva. Verifique os dados informados.";
            }

        } catch (Throwable $e) {

            $erro =
                "Erro ao realizar a reserva: "
                . $e->getMessage();
        }
    }
}

?>

<!DOCTYPE html>

<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Nova Reserva - Koinon Service</title>


    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >


    <style>

        body {
            background: #f5f6f8;
        }

        .container-reserva {
            max-width: 850px;
            margin: 40px auto;
        }

        .card-reserva {
            border: none;
            border-radius: 16px;
            box-shadow: 0 4px 18px rgba(0, 0, 0, 0.08);
        }

        .titulo {
            font-weight: 700;
        }

        .subtitulo {
            color: #6c757d;
        }

        .local-selecionado {
            display: none;
            border-radius: 10px;
        }

        .info-duracao {
            display: none;
            border-radius: 10px;
        }

        .campo-fim {
            background-color: #f1f3f5;
            cursor: not-allowed;
        }

        .resumo-reserva {
            display: none;
            border-radius: 10px;
        }

        /*
         * Área de disponibilidade.
         */
        .disponibilidade-reserva {
            display: none;
            border-radius: 10px;
        }

        .disponibilidade-reserva.verificando {
            display: block;
        }

        .disponibilidade-reserva.disponivel {
            display: block;
        }

        .disponibilidade-reserva.indisponivel {
            display: block;
        }

    </style>


    <link rel="stylesheet" href="../../assets/css/estilo.css">

</head>


<body>


<div class="container container-reserva">

    <div class="card card-reserva">

        <div class="card-body p-4 p-md-5">


            <div class="mb-4">

                <h2 class="titulo">
                    Nova Reserva
                </h2>

                <p class="subtitulo mb-0">
                    Solicite a reserva de uma área do condomínio.
                </p>

            </div>


            <?php if ($erro !== ""): ?>

                <div
                    class="alert alert-danger"
                    role="alert"
                >

                    <?= htmlspecialchars($erro) ?>

                </div>

            <?php endif; ?>


            <?php if (count($locais) === 0): ?>

                <div class="alert alert-warning">

                    <strong>
                        Nenhum local disponível.
                    </strong>

                    <br>

                    Não existem áreas de reserva ativas no momento.

                </div>


            <?php else: ?>


                <form
                    method="POST"
                    action=""
                    id="formReserva"
                >


                    <!-- LOCAL -->

                    <div class="mb-4">

                        <label
                            for="espaco_nome"
                            class="form-label fw-semibold"
                        >
                            Local da reserva
                        </label>


                        <select
                            name="espaco_nome"
                            id="espaco_nome"
                            class="form-select form-select-lg"
                            required
                        >

                            <option value="">
                                Selecione um local
                            </option>


                            <?php foreach ($locais as $local): ?>

                                <?php

                                $nomeLocal =
                                    (string) $local->getNome();

                                $duracaoMin =
                                    $configuracoesLocais[$nomeLocal]["min"]
                                    ?? 60;

                                $duracaoMax =
                                    $configuracoesLocais[$nomeLocal]["max"]
                                    ?? $duracaoMin;

                                ?>

                                <option
                                    value="<?= htmlspecialchars($nomeLocal) ?>"
                                    data-duracao-min="<?= (int) $duracaoMin ?>"
                                    data-duracao-max="<?= (int) $duracaoMax ?>"
                                    <?= $espacoNome === $nomeLocal ? "selected" : "" ?>
                                >

                                    <?= htmlspecialchars($nomeLocal) ?>

                                </option>

                            <?php endforeach; ?>

                        </select>


                        <div class="form-text">

                            Selecione a área que deseja reservar.

                        </div>

                    </div>


                    <!-- LOCAL SELECIONADO -->

                    <div
                        id="localSelecionado"
                        class="alert alert-info local-selecionado mb-4"
                    >

                        <strong>
                            Local selecionado:
                        </strong>

                        <span id="nomeLocalSelecionado"></span>

                    </div>


                    <!-- ÁLBUM DO LOCAL -->

                    <div id="albumLocal" class="mb-4" style="display:none;">
                        <div class="card border-0 shadow-sm">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <strong>📷 Fotos do local</strong>
                                    <small class="text-muted" id="contadorFotosLocal"></small>
                                </div>
                                <div id="galeriaLocal" class="row g-3"></div>
                            </div>
                        </div>
                    </div>


                    <!-- DURAÇÃO -->

                    <div
                        id="blocoDuracao"
                        class="mb-4"
                    >

                        <label
                            for="duracao"
                            class="form-label fw-semibold"
                        >
                            Duração da reserva
                        </label>


                        <select
                            id="duracao"
                            class="form-select"
                            disabled
                        >

                            <option value="">
                                Selecione o local primeiro
                            </option>

                        </select>


                        <div
                            id="infoDuracao"
                            class="alert alert-secondary info-duracao mt-2 mb-0"
                        >

                            <span id="textoDuracao"></span>

                        </div>


                        <div class="form-text">

                            A duração disponível depende da configuração
                            do local.

                        </div>

                    </div>


                    <!-- DATA INÍCIO E FIM -->

                    <div class="row">


                        <div class="col-md-6 mb-4">

                            <label
                                for="data_inicio"
                                class="form-label fw-semibold"
                            >
                                Data e horário de início
                            </label>


                            <input
                                type="datetime-local"
                                name="data_inicio"
                                id="data_inicio"
                                class="form-control"
                                value="<?= htmlspecialchars($dataInicio) ?>"
                                required
                            >


                            <div class="form-text">

                                Escolha quando deseja iniciar a utilização.

                            </div>

                        </div>


                        <div class="col-md-6 mb-4">

                            <label
                                for="data_fim"
                                class="form-label fw-semibold"
                            >
                                Data e horário de término
                            </label>


                            <input
                                type="datetime-local"
                                name="data_fim"
                                id="data_fim"
                                class="form-control campo-fim"
                                value="<?= htmlspecialchars($dataFim) ?>"
                                readonly
                                required
                            >


                            <div class="form-text">

                                O término será calculado automaticamente.

                            </div>

                        </div>

                    </div>


                    <!-- DISPONIBILIDADE -->

                    <div
                        id="disponibilidadeReserva"
                        class="alert disponibilidade-reserva mb-4"
                        role="alert"
                        aria-live="polite"
                    >

                        <span id="iconeDisponibilidade"></span>

                        <strong id="tituloDisponibilidade"></strong>

                        <div
                            id="textoDisponibilidade"
                            class="mt-1"
                        ></div>

                    </div>


                    <!-- RESUMO -->

                    <div
                        id="resumoReserva"
                        class="alert alert-success resumo-reserva mb-4"
                    >

                        <strong>
                            Resumo da reserva
                        </strong>

                        <br>

                        <span id="textoResumo"></span>

                    </div>


                    <!-- QUANTIDADE -->

                    <div class="mb-4">

                        <label
                            for="quantidade_pessoas"
                            class="form-label fw-semibold"
                        >
                            Quantidade de pessoas
                        </label>


                        <input
                            type="number"
                            name="quantidade_pessoas"
                            id="quantidade_pessoas"
                            class="form-control"
                            min="1"
                            value="<?= (int) $quantidadePessoas ?>"
                            required
                        >


                        <div class="form-text">

                            Informe a quantidade de pessoas que
                            utilizarão o espaço.

                        </div>

                    </div>


                    <!-- AVISO -->

                    <div class="alert alert-secondary">

                        <strong>
                            Importante:
                        </strong>

                        <br>

                        O horário de término é calculado
                        automaticamente de acordo com a duração
                        permitida para o local.

                        <br><br>

                        Se já existir outra reserva
                        <strong>pendente ou confirmada</strong>
                        no mesmo local e horário, o sistema
                        não permitirá a nova reserva.

                        <br><br>

                        A solicitação será enviada como
                        <strong>Pendente</strong>.

                    </div>


                    <!-- BOTÕES -->

                    <div class="d-flex gap-2">

                        <a
                            href="index.php"
                            class="btn btn-secondary"
                        >
                            Voltar
                        </a>


                        <button
                            type="submit"
                            class="btn btn-primary"
                            id="btnSolicitar"
                        >
                            Solicitar reserva
                        </button>

                    </div>


                </form>


            <?php endif; ?>


        </div>

    </div>

</div>


<script>

const configuracoesFotosLocais = <?= json_encode(
    $configuracoesLocais,
    JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
) ?>;

function atualizarAlbumLocal(nome) {
    const bloco = document.getElementById("albumLocal");
    const galeria = document.getElementById("galeriaLocal");
    const contador = document.getElementById("contadorFotosLocal");
    if (!bloco || !galeria) return;
    const dados = configuracoesFotosLocais[nome] || {};
    const fotos = Array.isArray(dados.fotos) ? dados.fotos : [];
    galeria.innerHTML = "";
    if (!fotos.length) { bloco.style.display = "none"; return; }
    fotos.forEach(function(foto, indice) {
        const col = document.createElement("div");
        col.className = "col-6 col-md-4";
        const img = document.createElement("img");
        img.src = "../../" + foto;
        img.alt = "Foto " + (indice + 1) + " do local";
        img.className = "w-100 rounded shadow-sm";
        img.style.height = "170px";
        img.style.objectFit = "cover";
        img.loading = "lazy";
        col.appendChild(img);
        galeria.appendChild(col);
    });
    contador.textContent = fotos.length + (fotos.length === 1 ? " foto" : " fotos");
    bloco.style.display = "block";
}

/*
 * ==========================================================
 * ELEMENTOS PRINCIPAIS
 * ==========================================================
 */

const selectLocal =
    document.getElementById("espaco_nome");

const selectDuracao =
    document.getElementById("duracao");

const dataInicio =
    document.getElementById("data_inicio");

const dataFim =
    document.getElementById("data_fim");

const localSelecionado =
    document.getElementById("localSelecionado");

const nomeLocalSelecionado =
    document.getElementById("nomeLocalSelecionado");

const infoDuracao =
    document.getElementById("infoDuracao");

const textoDuracao =
    document.getElementById("textoDuracao");

const resumoReserva =
    document.getElementById("resumoReserva");

const textoResumo =
    document.getElementById("textoResumo");

const disponibilidadeReserva =
    document.getElementById("disponibilidadeReserva");

const iconeDisponibilidade =
    document.getElementById("iconeDisponibilidade");

const tituloDisponibilidade =
    document.getElementById("tituloDisponibilidade");

const textoDisponibilidade =
    document.getElementById("textoDisponibilidade");

const formReserva =
    document.getElementById("formReserva");

const btnSolicitar =
    document.getElementById("btnSolicitar");


/*
 * Guarda o último resultado da verificação.
 *
 * null  = ainda não verificado
 * true  = disponível
 * false = indisponível
 */

let reservaDisponivel = null;


/*
 * Controle para evitar que uma resposta antiga
 * do servidor sobrescreva uma consulta mais nova.
 */

let numeroConsultaDisponibilidade = 0;


/*
 * ==========================================================
 * FORMATA DURAÇÃO
 * ==========================================================
 */

function formatarDuracao(minutos) {

    minutos = parseInt(minutos);

    if (minutos === 60) {
        return "1 hora";
    }

    if (minutos < 60) {
        return minutos + " minutos";
    }

    const horas =
        Math.floor(minutos / 60);

    const minutosRestantes =
        minutos % 60;


    if (minutosRestantes === 0) {

        if (horas === 1) {
            return "1 hora";
        }

        return horas + " horas";
    }


    if (horas === 1) {

        return (
            "1 hora e "
            + minutosRestantes
            + " minutos"
        );
    }


    return (
        horas
        + " horas e "
        + minutosRestantes
        + " minutos"
    );
}


/*
 * ==========================================================
 * FORMATA DATETIME-LOCAL
 * ==========================================================
 */

function formatarDatetimeLocal(data) {

    const ano =
        data.getFullYear();

    const mes =
        String(
            data.getMonth() + 1
        ).padStart(2, "0");

    const dia =
        String(
            data.getDate()
        ).padStart(2, "0");

    const hora =
        String(
            data.getHours()
        ).padStart(2, "0");

    const minuto =
        String(
            data.getMinutes()
        ).padStart(2, "0");


    return (
        ano
        + "-"
        + mes
        + "-"
        + dia
        + "T"
        + hora
        + ":"
        + minuto
    );
}


/*
 * ==========================================================
 * LIMPA DISPONIBILIDADE
 * ==========================================================
 */

function limparDisponibilidade() {

    reservaDisponivel = null;

    if (!disponibilidadeReserva) {
        return;
    }

    disponibilidadeReserva.className =
        "alert disponibilidade-reserva mb-4";

    disponibilidadeReserva.style.display =
        "none";

    if (iconeDisponibilidade) {
        iconeDisponibilidade.textContent = "";
    }

    if (tituloDisponibilidade) {
        tituloDisponibilidade.textContent = "";
    }

    if (textoDisponibilidade) {
        textoDisponibilidade.textContent = "";
    }
}


/*
 * ==========================================================
 * MOSTRA DISPONIBILIDADE
 * ==========================================================
 */

function mostrarDisponibilidade(
    disponivel,
    mensagem
) {

    reservaDisponivel =
        disponivel === true;


    if (!disponibilidadeReserva) {
        return;
    }


    if (disponivel) {

        disponibilidadeReserva.className =
            "alert alert-success disponibilidade-reserva mb-4";

        disponibilidadeReserva.style.display =
            "block";


        if (iconeDisponibilidade) {
            iconeDisponibilidade.textContent =
                "🟢 ";
        }


        if (tituloDisponibilidade) {
            tituloDisponibilidade.textContent =
                "Horário disponível";
        }


        if (textoDisponibilidade) {

            textoDisponibilidade.textContent =
                mensagem ||
                "Este horário está disponível para solicitação.";
        }

        return;
    }


    disponibilidadeReserva.className =
        "alert alert-danger disponibilidade-reserva mb-4";

    disponibilidadeReserva.style.display =
        "block";


    if (iconeDisponibilidade) {
        iconeDisponibilidade.textContent =
            "🔴 ";
    }


    if (tituloDisponibilidade) {
        tituloDisponibilidade.textContent =
            "Horário indisponível";
    }


    if (textoDisponibilidade) {

        textoDisponibilidade.textContent =
            mensagem ||
            "Já existe uma reserva para este período.";
    }
}


/*
 * ==========================================================
 * MOSTRA STATUS DE VERIFICAÇÃO
 * ==========================================================
 */

function mostrarVerificando() {

    reservaDisponivel = null;


    if (!disponibilidadeReserva) {
        return;
    }


    disponibilidadeReserva.className =
        "alert alert-warning disponibilidade-reserva mb-4";

    disponibilidadeReserva.style.display =
        "block";


    if (iconeDisponibilidade) {
        iconeDisponibilidade.textContent =
            "⏳ ";
    }


    if (tituloDisponibilidade) {
        tituloDisponibilidade.textContent =
            "Verificando disponibilidade...";
    }


    if (textoDisponibilidade) {
        textoDisponibilidade.textContent =
            "Aguarde enquanto verificamos este horário.";
    }
}


/*
 * ==========================================================
 * VERIFICA DISPONIBILIDADE VIA AJAX
 * ==========================================================
 */

async function verificarDisponibilidade() {

    /*
     * Se os elementos não existirem,
     * não executa nada.
     */

    if (
        !selectLocal ||
        !dataInicio ||
        !dataFim
    ) {
        return;
    }


    const espaco =
        selectLocal.value.trim();

    const inicio =
        dataInicio.value.trim();

    const fim =
        dataFim.value.trim();


    /*
     * Ainda não temos todos os dados.
     */

    if (
        espaco === ""
        ||
        inicio === ""
        ||
        fim === ""
    ) {

        limparDisponibilidade();

        return;
    }


    /*
     * Verifica se a data final realmente
     * é posterior à inicial.
     */

    const inicioData =
        new Date(inicio);

    const fimData =
        new Date(fim);


    if (
        isNaN(inicioData.getTime())
        ||
        isNaN(fimData.getTime())
    ) {

        limparDisponibilidade();

        return;
    }


    if (fimData <= inicioData) {

        limparDisponibilidade();

        return;
    }


    /*
     * Nova consulta.
     */

    numeroConsultaDisponibilidade++;

    const consultaAtual =
        numeroConsultaDisponibilidade;


    mostrarVerificando();


    if (btnSolicitar) {

        btnSolicitar.disabled =
            true;
    }


    try {

        const parametros =
            new URLSearchParams({
                espaco_nome: espaco,
                data_inicio: inicio,
                data_fim: fim
            });


        const resposta =
            await fetch(
                "verificar_disponibilidade.php?"
                + parametros.toString(),
                {
                    method: "GET",
                    headers: {
                        "Accept":
                            "application/json"
                    },
                    cache: "no-store"
                }
            );


        /*
         * Se outra consulta já foi iniciada,
         * ignoramos esta resposta.
         */

        if (
            consultaAtual !==
            numeroConsultaDisponibilidade
        ) {
            return;
        }


        if (!resposta.ok) {

            throw new Error(
                "Erro HTTP "
                + resposta.status
            );
        }


        const resultado =
            await resposta.json();


        if (
            !resultado
            ||
            resultado.sucesso !== true
        ) {

            throw new Error(
                resultado?.mensagem
                ||
                "Não foi possível verificar a disponibilidade."
            );
        }


        mostrarDisponibilidade(
            resultado.disponivel === true,
            resultado.mensagem
        );


        /*
         * Só libera o botão quando o horário
         * estiver disponível.
         */

        if (btnSolicitar) {

            btnSolicitar.disabled =
                resultado.disponivel !== true;
        }


    } catch (erro) {

        /*
         * Se outra consulta já foi iniciada,
         * não altera a tela.
         */

        if (
            consultaAtual !==
            numeroConsultaDisponibilidade
        ) {
            return;
        }


        reservaDisponivel = null;


        if (disponibilidadeReserva) {

            disponibilidadeReserva.className =
                "alert alert-warning disponibilidade-reserva mb-4";

            disponibilidadeReserva.style.display =
                "block";
        }


        if (iconeDisponibilidade) {

            iconeDisponibilidade.textContent =
                "⚠️ ";
        }


        if (tituloDisponibilidade) {

            tituloDisponibilidade.textContent =
                "Não foi possível verificar";
        }


        if (textoDisponibilidade) {

            textoDisponibilidade.textContent =
                "A verificação automática falhou. A validação definitiva será feita ao solicitar a reserva.";
        }


        /*
         * Em caso de erro na consulta AJAX,
         * permitimos o envio porque o backend
         * fará a validação definitiva.
         */

        if (btnSolicitar) {

            btnSolicitar.disabled =
                false;
        }
    }
}


/*
 * ==========================================================
 * ATUALIZA HORÁRIO DE TÉRMINO
 * ==========================================================
 */

function atualizarHorarioFim() {

    if (
        !dataInicio ||
        !dataFim ||
        !selectDuracao
    ) {
        return;
    }


    /*
     * Sempre que o horário muda,
     * a disponibilidade anterior deixa
     * de ser válida.
     */

    limparDisponibilidade();


    if (
        dataInicio.value === ""
        ||
        selectDuracao.value === ""
    ) {

        dataFim.value = "";

        if (resumoReserva) {
            resumoReserva.style.display = "none";
        }

        return;
    }


    const inicio =
        new Date(dataInicio.value);


    if (isNaN(inicio.getTime())) {

        dataFim.value = "";

        return;
    }


    const duracao =
        parseInt(selectDuracao.value);


    if (
        isNaN(duracao)
        ||
        duracao <= 0
    ) {

        dataFim.value = "";

        return;
    }


    /*
     * Soma a duração escolhida.
     */

    const fim =
        new Date(
            inicio.getTime()
            + (duracao * 60 * 1000)
        );


    dataFim.value =
        formatarDatetimeLocal(fim);


    /*
     * Atualiza o resumo.
     */

    if (
        resumoReserva &&
        textoResumo
    ) {

        const nome =
            selectLocal.options[
                selectLocal.selectedIndex
            ].text.trim();


        const inicioTexto =
            inicio.toLocaleString(
                "pt-BR",
                {
                    dateStyle: "short",
                    timeStyle: "short"
                }
            );


        const fimTexto =
            fim.toLocaleString(
                "pt-BR",
                {
                    dateStyle: "short",
                    timeStyle: "short"
                }
            );


        textoResumo.innerHTML =
            "<strong>"
            + nome
            + "</strong>"
            + "<br>"
            + inicioTexto
            + " até "
            + fimTexto
            + "<br>"
            + "Duração: "
            + formatarDuracao(duracao);


        resumoReserva.style.display =
            "block";
    }


    /*
     * Depois de calcular o término,
     * verifica automaticamente se o período
     * está disponível.
     */

    verificarDisponibilidade();
}


/*
 * ==========================================================
 * ATUALIZA DURAÇÕES
 * ==========================================================
 */

function atualizarDuracoes() {

    if (
        !selectLocal ||
        !selectDuracao
    ) {
        return;
    }


    /*
     * Sempre que o local mudar,
     * precisamos zerar a disponibilidade anterior.
     */

    limparDisponibilidade();


    const opcao =
        selectLocal.options[
            selectLocal.selectedIndex
        ];


    if (
        !opcao
        ||
        !opcao.value
    ) {

        selectDuracao.innerHTML =
            '<option value="">Selecione o local primeiro</option>';

        selectDuracao.disabled = true;

        if (infoDuracao) {
            infoDuracao.style.display = "none";
        }

        if (localSelecionado) {
            localSelecionado.style.display = "none";
        }

        if (dataFim) {
            dataFim.value = "";
        }

        if (resumoReserva) {
            resumoReserva.style.display = "none";
        }

        return;
    }


    const min =
        parseInt(
            opcao.dataset.duracaoMin
        );


    const max =
        parseInt(
            opcao.dataset.duracaoMax
        );


    if (
        isNaN(min)
        ||
        isNaN(max)
        ||
        min <= 0
        ||
        max <= 0
    ) {

        selectDuracao.innerHTML =
            '<option value="">Duração não configurada</option>';

        selectDuracao.disabled = true;

        return;
    }


    /*
     * Mostra o local selecionado.
     */

    if (
        localSelecionado &&
        nomeLocalSelecionado
    ) {

        nomeLocalSelecionado.textContent =
            opcao.text.trim();

        localSelecionado.style.display =
            "block";
    }

    atualizarAlbumLocal(opcao.value);


    /*
     * Limpa as opções anteriores.
     */

    selectDuracao.innerHTML = "";


    /*
     * Duração fixa.
     */

    if (min === max) {

        const option =
            document.createElement("option");

        option.value = min;

        option.textContent =
            formatarDuracao(min);

        option.selected = true;

        selectDuracao.appendChild(option);

        selectDuracao.disabled = false;


        if (
            infoDuracao &&
            textoDuracao
        ) {

            textoDuracao.innerHTML =
                "Este local possui duração fixa de <strong>"
                + formatarDuracao(min)
                + "</strong>.";

            infoDuracao.style.display =
                "block";
        }


        atualizarHorarioFim();

        return;
    }


    /*
     * Duração variável.
     */

    let duracaoAtual = min;


    while (duracaoAtual <= max) {

        const option =
            document.createElement("option");

        option.value =
            duracaoAtual;

        option.textContent =
            formatarDuracao(duracaoAtual);

        selectDuracao.appendChild(option);


        /*
         * Incremento de 30 minutos.
         */

        duracaoAtual += 30;
    }


    /*
     * Se o máximo não cair exatamente
     * em um intervalo de 30 minutos,
     * adicionamos o máximo.
     */

    if (
        (max - min) % 30 !== 0
    ) {

        const option =
            document.createElement("option");

        option.value =
            max;

        option.textContent =
            formatarDuracao(max);

        selectDuracao.appendChild(option);
    }


    selectDuracao.disabled = false;


    if (
        infoDuracao &&
        textoDuracao
    ) {

        textoDuracao.innerHTML =
            "Você pode escolher uma duração entre <strong>"
            + formatarDuracao(min)
            + "</strong> e <strong>"
            + formatarDuracao(max)
            + "</strong>.";

        infoDuracao.style.display =
            "block";
    }


    /*
     * Seleciona inicialmente o mínimo.
     */

    selectDuracao.value =
        String(min);


    atualizarHorarioFim();
}


/*
 * ==========================================================
 * EVENTO: LOCAL
 * ==========================================================
 */

if (selectLocal) {

    selectLocal.addEventListener(
        "change",
        function() {

            atualizarDuracoes();

        }
    );
}


/*
 * ==========================================================
 * EVENTO: DURAÇÃO
 * ==========================================================
 */

if (selectDuracao) {

    selectDuracao.addEventListener(
        "change",
        function() {

            atualizarHorarioFim();

        }
    );
}


/*
 * ==========================================================
 * EVENTO: DATA/HORA
 * ==========================================================
 */

if (dataInicio) {

    dataInicio.addEventListener(
        "change",
        function() {

            atualizarHorarioFim();

        }
    );


    dataInicio.addEventListener(
        "input",
        function() {

            atualizarHorarioFim();

        }
    );
}


/*
 * ==========================================================
 * INICIALIZAÇÃO
 * ==========================================================
 */

if (selectLocal) {

    atualizarDuracoes();

}


/*
 * ==========================================================
 * VALIDAÇÃO ANTES DO ENVIO
 * ==========================================================
 */

if (formReserva) {

    formReserva.addEventListener(
        "submit",
        function(event) {

            if (
                !selectLocal
                ||
                !selectLocal.value
            ) {

                event.preventDefault();

                alert(
                    "Selecione o local da reserva."
                );

                return;
            }


            if (
                !selectDuracao
                ||
                !selectDuracao.value
            ) {

                event.preventDefault();

                alert(
                    "Selecione a duração da reserva."
                );

                return;
            }


            if (
                !dataInicio
                ||
                !dataInicio.value
            ) {

                event.preventDefault();

                alert(
                    "Informe a data e o horário de início."
                );

                return;
            }


            if (
                !dataFim
                ||
                !dataFim.value
            ) {

                event.preventDefault();

                alert(
                    "Não foi possível calcular o horário de término."
                );

                return;
            }


            const inicio =
                new Date(dataInicio.value);

            const fim =
                new Date(dataFim.value);


            if (
                isNaN(inicio.getTime())
                ||
                isNaN(fim.getTime())
            ) {

                event.preventDefault();

                alert(
                    "Verifique a data e o horário informados."
                );

                return;
            }


            if (fim <= inicio) {

                event.preventDefault();

                alert(
                    "O horário de término deve ser posterior ao horário de início."
                );

                return;
            }


            /*
             * Se a consulta confirmou que o horário
             * está ocupado, não deixa enviar.
             */

            if (reservaDisponivel === false) {

                event.preventDefault();

                alert(
                    "Este horário está indisponível. Escolha outro horário."
                );

                return;
            }


            /*
             * Se ainda estiver verificando,
             * impede o envio para evitar uma ação
             * antes da resposta do AJAX.
             */

            if (reservaDisponivel === null) {

                event.preventDefault();

                alert(
                    "Aguarde a verificação da disponibilidade do horário."
                );

                verificarDisponibilidade();

                return;
            }

        }
    );
}

</script>
<script src="../../assets/js/script.js"></script>

</body>

</html>