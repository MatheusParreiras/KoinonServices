<?php

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_once __DIR__ . "/../../controller/PermissaoController.php";
require_once __DIR__ . "/../../controller/MoradorController.php";

PermissaoController::exigirPerfil(["Morador"]);

$usuarioId = (int) $_SESSION["usuario_id"];
$cobrancaId = (int) ($_GET["id"] ?? 0);

$controller = new MoradorController();
$cobranca = $cobrancaId > 0
    ? $controller->buscarCobrancaUsuario($usuarioId, $cobrancaId)
    : null;

if (!$cobranca) {
    header("Location: index.php?boleto=nao_encontrado");
    exit;
}

$status = (string) ($cobranca["status"] ?? "Pendente");
$statusClass = match ($status) {
    "Pago" => "bg-success",
    "Pendente" => "bg-warning text-dark",
    "Vencido" => "bg-danger",
    "Cancelado" => "bg-secondary",
    default => "bg-dark"
};
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Boleto - Koinon Service</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../assets/css/estilo.css">
</head>
<body>

<div class="container py-4">
    <div class="koinon-page-back">
        <a href="index.php" class="btn btn-outline-secondary btn-sm">← Voltar</a>
    </div>

    <div class="koinon-hero p-4 p-lg-5 mb-4">
        <div class="d-flex flex-wrap justify-content-between gap-3 align-items-center">
            <div>
                <div class="text-white-50 small mb-2">Financeiro</div>
                <h1 class="h3 mb-2">Detalhes da cobrança</h1>
                <p class="mb-0 text-white-50">Consulte os dados do boleto e acesse o pagamento quando houver um link disponível.</p>
            </div>
            <span class="badge <?= $statusClass ?> fs-6 px-3 py-2"><?= htmlspecialchars($status) ?></span>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-lg-8">
            <div class="card h-100">
                <div class="card-body p-4">
                    <h2 class="h5 mb-4">Informações do boleto</h2>
                    <div class="row g-4">
                        <div class="col-md-8">
                            <div class="text-muted small">Descrição</div>
                            <div class="fw-semibold"><?= htmlspecialchars($cobranca["descricao"] ?? "Cobrança") ?></div>
                        </div>
                        <div class="col-md-4">
                            <div class="text-muted small">Valor</div>
                            <div class="fw-bold fs-5">R$ <?= number_format((float) ($cobranca["valor"] ?? 0), 2, ",", ".") ?></div>
                        </div>
                        <div class="col-md-4">
                            <div class="text-muted small">Vencimento</div>
                            <div class="fw-semibold"><?= !empty($cobranca["vencimento"]) ? date("d/m/Y", strtotime($cobranca["vencimento"])) : "—" ?></div>
                        </div>
                        <div class="col-md-8">
                            <div class="text-muted small">Linha digitável</div>
                            <div class="fw-semibold text-break"><?= htmlspecialchars($cobranca["linha_digitavel"] ?? "Não informada") ?></div>
                        </div>
                    </div>

                    <hr class="my-4">

                    <?php if (!empty($cobranca["link_boleto"])): ?>
                        <a href="<?= htmlspecialchars($cobranca["link_boleto"]) ?>" target="_blank" rel="noopener noreferrer" class="btn btn-primary btn-lg">
                            💳 Acessar boleto / Pagar
                        </a>
                    <?php elseif (!empty($cobranca["linha_digitavel"])): ?>
                        <button type="button" class="btn btn-primary btn-lg" onclick="navigator.clipboard.writeText(<?= json_encode($cobranca["linha_digitavel"]) ?>).then(() => this.innerText='✓ Linha copiada')">
                            📋 Copiar linha digitável
                        </button>
                        <p class="text-muted small mt-3 mb-0">O sistema não possui integração bancária própria. A linha digitável pode ser usada no aplicativo ou internet banking da instituição financeira.</p>
                    <?php elseif ($status === "Pago"): ?>
                        <div class="alert alert-success mb-0">Pagamento já registrado pela administração.</div>
                    <?php else: ?>
                        <div class="alert alert-info mb-0">O boleto ainda não possui link ou linha digitável cadastrados. Entre em contato com a administração.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card h-100">
                <div class="card-body p-4">
                    <h2 class="h5">Acompanhamento</h2>
                    <p class="text-muted">Depois do pagamento, o status é atualizado pela administração no módulo financeiro.</p>
                    <div class="d-grid gap-2">
                        <a href="index.php" class="btn btn-outline-primary">Voltar para meu painel</a>
                        <a href="notificacoes.php" class="btn btn-outline-secondary">Ver notificações</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="../../assets/js/script.js"></script>
</body>
</html>
