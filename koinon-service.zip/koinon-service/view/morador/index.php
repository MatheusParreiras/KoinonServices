<?php

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_once __DIR__ . "/../../controller/PermissaoController.php";
require_once __DIR__ . "/../../controller/MoradorController.php";

PermissaoController::exigirPerfil([
    "Morador"
]);

$usuarioId =
    (int) $_SESSION["usuario_id"];

$controller =
    new MoradorController();

$dashboard =
    $controller->carregarDashboard(
        $usuarioId
    );

$usuario =
    $dashboard->getUsuario();

$unidade =
    $dashboard->getUnidade();

$encomendas =
    $dashboard->getEncomendas();

$reservas =
    $dashboard->getReservas();

$ocorrencias =
    $dashboard->getOcorrencias();

$cobrancas =
    $dashboard->getCobrancas();

$autorizacoes =
    $dashboard->getAutorizacoes();

$publicacoes =
    $dashboard->getPublicacoes();

$documentos =
    $dashboard->getDocumentos();

$veiculos =
    $dashboard->getVeiculos();


?>

<!DOCTYPE html>

<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Área do Morador - Koinon Service
    </title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >


    <link rel="stylesheet" href="../../assets/css/estilo.css">

</head>

<body class="bg-light koinon-dashboard-page">


<!-- ==========================================================
     NAVBAR
========================================================== -->

<nav class="navbar navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand fw-bold text-white text-decoration-none" href="index.php">
            Koinon Service
        </a>

        <div class="d-flex align-items-center koinon-nav-actions">
            <span class="text-white small fw-semibold koinon-user-name">
                Olá, <?= htmlspecialchars($usuario["nome"] ?? "Morador") ?>
            </span>
            <a href="../../view/logout.php" class="btn btn-danger btn-sm koinon-logout-btn">Sair</a>
        </div>
    </div>
</nav>


<div class="container py-4">


<!-- ==========================================================
     MENSAGENS
========================================================== -->

<?php if (
    isset($_GET["sucesso"]) &&
    $_GET["sucesso"] === "ocorrencia"
): ?>

    <div class="alert alert-success">

        ✅ Ocorrência registrada com sucesso!

        <br>

        A administração poderá acompanhar e atualizar o atendimento.

    </div>

<?php endif; ?>


<?php if (isset($_GET["boleto"]) && $_GET["boleto"] === "nao_encontrado"): ?>
    <div class="alert alert-danger">❌ Cobrança não encontrada ou não pertence à sua unidade.</div>
<?php endif; ?>

<?php if (
    isset($_GET["reserva"])
): ?>

    <?php if (
        $_GET["reserva"] === "sucesso"
    ): ?>

        <div class="alert alert-success">

            ✅ Reserva solicitada com sucesso!

            <br>

            Aguarde a confirmação da administração.

        </div>

    <?php elseif (
        $_GET["reserva"] === "cancelada"
    ): ?>

        <div class="alert alert-success">

            ✅ Reserva cancelada com sucesso!

        </div>

    <?php elseif (
        $_GET["reserva"] === "erro"
    ): ?>

        <div class="alert alert-danger">

            ❌ Não foi possível realizar a operação da reserva.

        </div>

    <?php endif; ?>

<?php endif; ?>


<!-- ==========================================================
     CABEÇALHO
========================================================== -->

<div class="koinon-hero p-4 p-lg-5 mb-4">
    <div class="row align-items-center g-4">
        <div class="col-lg-8">
            <div class="text-white-50 small mb-2">Painel do morador</div>
            <h1 class="h2 fw-bold mb-2">Olá, <?= htmlspecialchars($usuario["nome"] ?? "Morador") ?> 👋</h1>
            <p class="mb-0 text-white-50">Acompanhe sua unidade, reservas, cobranças, encomendas e solicitações em um só lugar.</p>
        </div>

    </div>
</div>


<!-- ==========================================================
     RESUMO E AÇÕES
========================================================== -->

<div class="row g-3 mb-4">
    <div class="col-6 col-xl-3">
        <div class="koinon-stat">
            <div class="koinon-stat-icon mb-3">💰</div>
            <div class="text-muted small">Cobranças</div>
            <div class="h4 fw-bold mb-1"><?= count($cobrancas) ?></div>
            <a href="#financeiro" class="small text-decoration-none">Ver financeiro →</a>
        </div>
    </div>
    <div class="col-6 col-xl-3">
        <div class="koinon-stat">
            <div class="koinon-stat-icon mb-3">📅</div>
            <div class="text-muted small">Reservas</div>
            <div class="h4 fw-bold mb-1"><?= count($reservas) ?></div>
            <a href="#reservas" class="small text-decoration-none">Acompanhar →</a>
        </div>
    </div>
    <div class="col-6 col-xl-3">
        <div class="koinon-stat">
            <div class="koinon-stat-icon mb-3">📦</div>
            <div class="text-muted small">Encomendas</div>
            <div class="h4 fw-bold mb-1"><?= count($encomendas) ?></div>
            <a href="encomendas.php" class="small text-decoration-none">Ver encomendas →</a>
        </div>
    </div>
    <div class="col-6 col-xl-3">
        <div class="koinon-stat">
            <div class="koinon-stat-icon mb-3">🚗</div>
            <div class="text-muted small">Veículos</div>
            <div class="h4 fw-bold mb-1"><?= count($veiculos) ?></div>
            <div class="small text-muted mb-1">
                <?= count($veiculos) ?> / <?= (int)($unidade["quantidade_vagas"] ?? 0) ?> vagas ocupadas
            </div>
            <a href="#veiculos" class="small text-decoration-none">Visualizar →</a>
        </div>
    </div>
</div>

<!-- Ações ficam nos próprios módulos abaixo para evitar acessos duplicados. -->

<div class="row g-4">


<!-- ==========================================================
     MEUS DADOS
========================================================== -->

<div class="col-md-6">

    <div class="card shadow-sm h-100">

        <div class="card-header bg-primary text-white">

            👤 Meus dados

        </div>

        <div class="card-body">

            <p>

                <strong>
                    Nome:
                </strong>

                <?= htmlspecialchars(
                    $usuario["nome"] ?? ""
                ) ?>

            </p>

            <p>

                <strong>
                    CPF:
                </strong>

                <?= htmlspecialchars(
                    $usuario["cpf"] ?? ""
                ) ?>

            </p>

            <p>

                <strong>
                    E-mail:
                </strong>

                <?= htmlspecialchars(
                    $usuario["email"] ?? ""
                ) ?>

            </p>

            <p class="mb-0">

                <strong>
                    Perfil:
                </strong>

                <span class="badge bg-primary">

                    Morador

                </span>

            </p>

        </div>

    </div>

</div>


<!-- ==========================================================
     UNIDADE
========================================================== -->

<div class="col-12 col-lg-4">

    <div class="card shadow-sm h-100">

        <div class="card-header bg-dark text-white">

            🏠 Minha unidade

        </div>

        <div class="card-body">

            <?php if ($unidade): ?>

                <p>

                    <strong>
                        Identificação:
                    </strong>

                    <?= htmlspecialchars(
                        $unidade["identificacao"]
                    ) ?>

                </p>

                <p>

                    <strong>
                        Tipo:
                    </strong>

                    <?= htmlspecialchars(
                        $unidade["tipo_unidade"]
                    ) ?>

                </p>


            <?php else: ?>

                <p class="text-muted mb-0">

                    Nenhuma unidade vinculada.

                </p>

            <?php endif; ?>

        </div>

    </div>

</div>


<!-- ==========================================================
     VEÍCULOS E VAGAS — SOMENTE VISUALIZAÇÃO PARA O MORADOR
========================================================== -->

<div class="col-12 col-lg-4" id="veiculos">
    <div class="koinon-vehicle-card p-4 h-100">
        <div class="d-flex justify-content-between align-items-start gap-3 mb-3">
            <div>
                <div class="small text-muted">Garagem da unidade</div>
                <h2 class="h5 fw-bold mb-1">🚗 Meus veículos</h2>
                <p class="small text-muted mb-0">Visualização dos veículos cadastrados pela administração.</p>
            </div>
            <span class="koinon-parking-badge">🅿️ <?= count($veiculos) ?> / <?= (int)($unidade["quantidade_vagas"] ?? 0) ?> vagas</span>
        </div>

        <?php if (empty($veiculos)): ?>
            <div class="text-muted small">Nenhum veículo cadastrado para esta unidade.</div>
        <?php else: ?>
            <div class="d-grid gap-2">
                <?php foreach ($veiculos as $veiculo): ?>
                    <div class="koinon-vehicle-item p-3">
                        <div class="d-flex justify-content-between align-items-center gap-3">
                            <div>
                                <div class="fw-bold"><?= htmlspecialchars($veiculo["modelo"] ?? "Veículo") ?></div>
                                <div class="small text-muted">
                                    Placa: <?= htmlspecialchars($veiculo["placa"] ?? "—") ?>
                                    <?php if (!empty($veiculo["cor"])): ?> · Cor: <?= htmlspecialchars($veiculo["cor"]) ?><?php endif; ?>
                                </div>
                            </div>
                            <span class="badge text-bg-secondary">Somente consulta</span>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- ==========================================================
     AUTORIZAÇÕES / VISITANTES
========================================================== -->

<div class="col-12 col-lg-4">
    <div class="koinon-resident-extra-card p-4 h-100">
        <div class="d-flex justify-content-between align-items-start gap-3 mb-3">
            <div>
                <div class="small text-muted">Controle de acesso</div>
                <h2 class="h5 fw-bold mb-1">👥 Minhas autorizações</h2>
                <p class="small text-muted mb-0">Consulte os visitantes autorizados para sua unidade.</p>
            </div>
            <span class="badge text-bg-primary"><?= count($autorizacoes) ?></span>
        </div>
        <?php if (empty($autorizacoes)): ?>
            <div class="text-muted small mb-3">Nenhuma autorização cadastrada.</div>
        <?php else: ?>
            <?php $autorizacaoResumo = $autorizacoes[0]; ?>
            <div class="koinon-vehicle-item p-3 mb-3">
                <div class="fw-bold"><?= htmlspecialchars($autorizacaoResumo["visitante_nome"] ?? "Visitante") ?></div>
                <div class="small text-muted mt-1">
                    Status: <?= htmlspecialchars($autorizacaoResumo["status"] ?? "—") ?>
                </div>
            </div>
        <?php endif; ?>
        <div class="small text-muted">O gerenciamento completo está no bloco de Autorizações de acesso abaixo.</div>
    </div>
</div>

<!-- ==========================================================
     RESERVAS
========================================================== -->

<div class="col-12" id="reservas">

    <div class="card shadow-sm">

        <div
            class="card-header d-flex justify-content-between align-items-center"
        >

            <span>

                📅 Minhas reservas

            </span>

            <a
                href="nova_reserva.php"
                class="btn btn-sm btn-success"
            >

                + Nova reserva

            </a>

        </div>

        <div class="card-body">

            <?php if (
                empty($reservas)
            ): ?>

                <p class="text-muted">

                    Nenhuma reserva encontrada.

                </p>

            <?php else: ?>

                <div class="table-responsive">

                    <table class="table table-bordered">

                        <thead class="table-light">

                            <tr>

                                <th>
                                    Espaço
                                </th>

                                <th>
                                    Início
                                </th>

                                <th>
                                    Fim
                                </th>

                                <th>
                                    Status
                                </th>

                                <th>
                                    Acesso
                                </th>

                                <th>
                                    Taxa
                                </th>

                                <th>
                                    Ação
                                </th>

                            </tr>

                        </thead>

                        <tbody>

                        <?php foreach (
                            $reservas
                            as $reserva
                        ): ?>

                            <tr>

                                <td>

                                    <?= htmlspecialchars(
                                        $reserva["espaco_nome"]
                                    ) ?>

                                </td>

                                <td>

                                    <?= date(
                                        "d/m/Y H:i",
                                        strtotime(
                                            $reserva["data_inicio"]
                                        )
                                    ) ?>

                                </td>

                                <td>

                                    <?= date(
                                        "d/m/Y H:i",
                                        strtotime(
                                            $reserva["data_fim"]
                                        )
                                    ) ?>

                                </td>

                                <td>

                                    <?php
                                    $classeStatus =
                                        match (
                                            $reserva["status"]
                                        ) {
                                            "Confirmada"
                                                => "bg-success",

                                            "Pendente"
                                                => "bg-warning text-dark",

                                            "Cancelada"
                                                => "bg-danger",

                                            "Concluida"
                                                => "bg-secondary",

                                            default
                                                => "bg-dark"
                                        };
                                    ?>

                                    <span class="badge <?= $classeStatus ?>">
                                        <?= htmlspecialchars($reserva["status"]) ?>
                                    </span>

                                    <?php if ((float) ($reserva["valor_taxa"] ?? 0) > 0 && ($reserva["status"] ?? "") === "Confirmada"): ?>
                                        <?php $pagamentoReserva = $reserva["pagamento_status"] ?? null; ?>
                                        <div class="small mt-2">
                                            <?php if ($pagamentoReserva === "Pago"): ?>
                                                <span class="badge bg-success">✓ Pagamento confirmado</span>
                                                <div class="text-success mt-1">Local reservado com sucesso.</div>
                                            <?php elseif ($pagamentoReserva === "Vencido"): ?>
                                                <span class="badge bg-danger">Pagamento vencido</span>
                                                <div class="mt-1"><a href="#financeiro" class="text-decoration-none">Acessar cobrança</a></div>
                                            <?php else: ?>
                                                <span class="badge bg-warning text-dark">Pendente pagamento</span>
                                                <div class="text-muted mt-1">A reserva está confirmada e aguarda o pagamento.</div>
                                            <?php endif; ?>
                                        </div>
                                    <?php elseif ((float) ($reserva["valor_taxa"] ?? 0) <= 0 && ($reserva["status"] ?? "") === "Confirmada"): ?>
                                        <div class="small text-success mt-2">✓ Local reservado com sucesso.</div>
                                    <?php endif; ?>

                                </td>

                                <td>

                                    R$

                                    <?= number_format(
                                        (float) $reserva["valor_taxa"],
                                        2,
                                        ",",
                                        "."
                                    ) ?>

                                </td>

                                <td>

                                    <?php if (
                                        in_array(
                                            $reserva["status"],
                                            [
                                                "Pendente",
                                                "Confirmada"
                                            ],
                                            true
                                        )
                                    ): ?>

                                        <a
                                            href="cancelar_reserva.php?id=<?= (int) $reserva["id"] ?>"
                                            class="btn btn-sm btn-outline-danger"
                                            onclick="return confirm('Deseja cancelar esta reserva?');"
                                        >

                                            Cancelar

                                        </a>

                                    <?php else: ?>

                                        <span class="text-muted">

                                            —

                                        </span>

                                    <?php endif; ?>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            <?php endif; ?>

        </div>

    </div>

</div>


<!-- ==========================================================
     OCORRÊNCIAS
========================================================== -->

<div class="col-12">

    <div class="card shadow-sm">

        <div
            class="card-header d-flex justify-content-between align-items-center"
        >

            <span>

                ⚠️ Minhas ocorrências

            </span>

            <a
                href="nova_ocorrencia.php"
                class="btn btn-sm btn-warning"
            >

                + Registrar ocorrência

            </a>

        </div>

        <div class="card-body">

            <?php if (
                empty($ocorrencias)
            ): ?>

                <p class="text-muted">

                    Você ainda não registrou nenhuma ocorrência.

                </p>

            <?php else: ?>

                <div class="table-responsive">

                    <table class="table table-bordered align-middle">

                        <thead class="table-light">

                            <tr>

                                <th>
                                    Título
                                </th>

                                <th>
                                    Tipo
                                </th>

                                <th>
                                    Descrição
                                </th>

                                <th>
                                    Data
                                </th>

                                <th>
                                    Status
                                </th>

                                <th>
                                    Foto
                                </th>

                            </tr>

                        </thead>

                        <tbody>

                        <?php foreach (
                            $ocorrencias
                            as $ocorrencia
                        ): ?>

                            <tr>

                                <td>

                                    <strong>

                                        <?= htmlspecialchars(
                                            $ocorrencia["titulo"]
                                        ) ?>

                                    </strong>

                                </td>

                                <td>

                                    <?= htmlspecialchars(
                                        $ocorrencia["tipo"]
                                    ) ?>

                                </td>

                                <td>

                                    <?= nl2br(
                                        htmlspecialchars(
                                            $ocorrencia["descricao"]
                                        )
                                    ) ?>

                                </td>

                                <td>

                                    <?= date(
                                        "d/m/Y H:i",
                                        strtotime(
                                            $ocorrencia["data_abertura"]
                                        )
                                    ) ?>

                                </td>

                                <td>

                                    <?php
                                    $classeOcorrencia =
                                        match (
                                            $ocorrencia["status"]
                                        ) {
                                            "Aberta"
                                                => "bg-danger",

                                            "Em_Andamento"
                                                => "bg-warning text-dark",

                                            "Resolvida"
                                                => "bg-success",

                                            "Cancelada"
                                                => "bg-secondary",

                                            default
                                                => "bg-dark"
                                        };
                                    ?>

                                    <span
                                        class="badge <?= $classeOcorrencia ?>"
                                    >

                                        <?= htmlspecialchars(
                                            $ocorrencia["status"]
                                        ) ?>

                                    </span>

                                </td>

                                <td>

                                    <?php if (
                                        !empty(
                                            $ocorrencia["foto_url"]
                                        )
                                    ): ?>

                                        <a
                                            href="<?= htmlspecialchars(
                                                $ocorrencia["foto_url"]
                                            ) ?>"
                                            target="_blank"
                                            class="btn btn-sm btn-outline-primary"
                                        >

                                            Ver foto

                                        </a>

                                    <?php else: ?>

                                        <span class="text-muted">

                                            Sem foto

                                        </span>

                                    <?php endif; ?>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            <?php endif; ?>

        </div>

    </div>

</div>


<!-- ==========================================================
     ENCOMENDAS
========================================================== -->

<div class="col-md-6">

    <div class="card shadow-sm h-100">

        <div class="card-header">

            📦 Minhas encomendas

        </div>

        <div class="card-body">

            <?php if (
                empty($encomendas)
            ): ?>

                <p class="text-muted">

                    Nenhuma encomenda encontrada.

                </p>

            <?php else: ?>

                <?php foreach (
                    $encomendas
                    as $encomenda
                ): ?>

                    <div
                        class="border-bottom pb-2 mb-2"
                    >

                        <strong>

                            <?= htmlspecialchars(
                                $encomenda["descricao"]
                            ) ?>

                        </strong>

                        <br>

                        <small class="text-muted">

                            Status:

                            <?= htmlspecialchars(
                                $encomenda["status"]
                            ) ?>

                        </small>

                        <?php if (
                            !empty(
                                $encomenda["codigo_rastreio"]
                            )
                        ): ?>

                            <br>

                            <small>

                                Rastreio:

                                <?= htmlspecialchars(
                                    $encomenda["codigo_rastreio"]
                                ) ?>

                            </small>

                        <?php endif; ?>

                    </div>

                <?php endforeach; ?>

            <?php endif; ?>

        </div>

    </div>

</div>


<!-- ==========================================================
     FINANCEIRO
========================================================== -->

<div class="col-md-6" id="financeiro">

    <div class="card shadow-sm h-100">

        <div class="card-header">

            💰 Minhas cobranças

        </div>

        <div class="card-body">

            <?php if (
                empty($cobrancas)
            ): ?>

                <p class="text-muted">

                    Nenhuma cobrança encontrada.

                </p>

            <?php else: ?>

                <div class="table-responsive">

                    <table class="table table-sm">

                        <thead>

                            <tr>

                                <th>
                                    Descrição
                                </th>

                                <th>
                                    Valor
                                </th>

                                <th>
                                    Vencimento
                                </th>

                                <th>
                                    Status
                                </th>

                            </tr>

                        </thead>

                        <tbody>

                        <?php foreach (
                            $cobrancas
                            as $cobranca
                        ): ?>

                            <tr>

                                <td>

                                    <?= htmlspecialchars(
                                        $cobranca["descricao"]
                                    ) ?>

                                </td>

                                <td>

                                    R$

                                    <?= number_format(
                                        (float) $cobranca["valor"],
                                        2,
                                        ",",
                                        "."
                                    ) ?>

                                </td>

                                <td>

                                    <?= date(
                                        "d/m/Y",
                                        strtotime(
                                            $cobranca["vencimento"]
                                        )
                                    ) ?>

                                </td>

                                <td>

                                    <?php
                                    $classeCobranca =
                                        match (
                                            $cobranca["status"]
                                        ) {
                                            "Pago"
                                                => "bg-success",

                                            "Pendente"
                                                => "bg-warning text-dark",

                                            "Vencido"
                                                => "bg-danger",

                                            "Cancelado"
                                                => "bg-secondary",

                                            default
                                                => "bg-dark"
                                        };
                                    ?>

                                    <span
                                        class="badge <?= $classeCobranca ?>"
                                    >

                                        <?= htmlspecialchars(
                                            $cobranca["status"]
                                        ) ?>

                                    </span>

                                    <div class="mt-2">
                                        <a href="boleto.php?id=<?= (int) $cobranca["id"] ?>" class="btn btn-sm btn-outline-primary">
                                            <?= !empty($cobranca["link_boleto"]) || !empty($cobranca["linha_digitavel"]) ? "💳 Acessar boleto" : "👁 Ver cobrança" ?>
                                        </a>
                                    </div>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

                <div class="alert alert-info mb-0">

                    ℹ️ Quando houver boleto ou linha digitável cadastrados, você poderá acessá-los por aqui. O registro da quitação continua sendo feito pela administração.

                </div>

            <?php endif; ?>

        </div>

    </div>

</div>


<!-- ==========================================================
     AUTORIZAÇÕES
========================================================== -->

<div class="col-12">

    <div class="card shadow-sm">

        <div class="card-header d-flex justify-content-between align-items-center">

            <span>

                👥 Autorizações de acesso

            </span>

            <div>

                <a
                    href="autorizacoes.php"
                    class="btn btn-sm btn-outline-primary"
                >

                    Ver autorizações

                </a>

                <a
                    href="nova_autorizacao.php"
                    class="btn btn-sm btn-primary"
                >

                    + Nova autorização

                </a>

            </div>

        </div>

        <div class="card-body">

            <?php if (
                empty($autorizacoes)
            ): ?>

                <p class="text-muted">

                    Nenhuma autorização encontrada.

                </p>

            <?php else: ?>

                <div class="table-responsive">

                    <table class="table table-bordered">

                        <thead class="table-light">

                            <tr>

                                <th>
                                    Visitante
                                </th>

                                <th>
                                    Documento
                                </th>

                                <th>
                                    Tipo
                                </th>

                                <th>
                                    Início
                                </th>

                                <th>
                                    Fim
                                </th>

                                <th>
                                    Status
                                </th>

                            </tr>

                        </thead>

                        <tbody>

                        <?php foreach (
                            $autorizacoes
                            as $autorizacao
                        ): ?>

                            <tr>

                                <td>

                                    <?= htmlspecialchars(
                                        $autorizacao["visitante_nome"]
                                    ) ?>

                                </td>

                                <td>

                                    <?= htmlspecialchars(
                                        $autorizacao["visitante_documento"]
                                    ) ?>

                                </td>

                                <td>

                                    <?= htmlspecialchars(
                                        $autorizacao["tipo_visitante"]
                                    ) ?>

                                </td>

                                <td>

                                    <?= date(
                                        "d/m/Y H:i",
                                        strtotime(
                                            $autorizacao["data_inicio"]
                                        )
                                    ) ?>

                                </td>

                                <td>

                                    <?= date(
                                        "d/m/Y H:i",
                                        strtotime(
                                            $autorizacao["data_fim"]
                                        )
                                    ) ?>

                                </td>

                                <td>

                                    <?= htmlspecialchars(
                                        $autorizacao["status"]
                                    ) ?>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            <?php endif; ?>

        </div>

    </div>

</div>


<!-- ==========================================================
     PUBLICAÇÕES
========================================================== -->

<div class="col-md-6">

    <div class="card shadow-sm h-100">

        <div class="card-header">

            📢 Publicações do condomínio

        </div>

        <div class="card-body">

            <?php if (
                empty($publicacoes)
            ): ?>

                <p class="text-muted">

                    Nenhuma publicação disponível.

                </p>

            <?php else: ?>

                <?php foreach (
                    $publicacoes
                    as $publicacao
                ): ?>

                    <div
                        class="border-bottom mb-3 pb-3"
                    >

                        <h6>

                            <?= htmlspecialchars(
                                $publicacao["titulo"]
                            ) ?>

                        </h6>

                        <p>

                            <?= nl2br(
                                htmlspecialchars(
                                    $publicacao["conteudo"]
                                )
                            ) ?>

                        </p>

                        <small class="text-muted">

                            Publicado por:

                            <?= htmlspecialchars(
                                $publicacao["autor_nome"]
                            ) ?>

                        </small>

                    </div>

                <?php endforeach; ?>

            <?php endif; ?>

        </div>

    </div>

</div>


<!-- ==========================================================
     DOCUMENTOS
========================================================== -->

<div class="col-md-6">

    <div class="card shadow-sm h-100">

        <div class="card-header">

            📄 Documentos do condomínio

        </div>

        <div class="card-body">

            <?php if (
                empty($documentos)
            ): ?>

                <p class="text-muted">

                    Nenhum documento disponível.

                </p>

            <?php else: ?>

                <?php foreach (
                    $documentos
                    as $documento
                ): ?>

                    <div
                        class="border-bottom pb-2 mb-2"
                    >

                        <strong>

                            <?= htmlspecialchars(
                                $documento["titulo"]
                            ) ?>

                        </strong>

                        <br>

                        <small class="text-muted">

                            <?= htmlspecialchars(
                                $documento["categoria"]
                            ) ?>

                        </small>

                        <?php if (
                            !empty(
                                $documento["arquivo_url"]
                            )
                        ): ?>

                            <br>

                            <a
                                href="<?= htmlspecialchars(
                                    $documento["arquivo_url"]
                                ) ?>"
                                target="_blank"
                                class="btn btn-sm btn-outline-primary mt-2"
                            >

                                Abrir documento

                            </a>

                        <?php endif; ?>

                    </div>

                <?php endforeach; ?>

            <?php endif; ?>

        </div>

    </div>

</div>


</div>

</div>


<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
></script>
<script src="../../assets/js/script.js"></script>

</body>

</html>