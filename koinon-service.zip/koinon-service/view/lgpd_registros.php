<?php
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

require_once __DIR__ . "/../controller/PermissaoController.php";
require_once __DIR__ . "/../model/dao/Conexao.php";

PermissaoController::exigirPerfil(["Administrador", "Sindico"]);

$conexao = Conexao::conectar();

$sql = "
    SELECT
        u.id,
        u.nome,
        u.cpf,
        u.email,
        u.telefone,
        u.perfil,
        u.termo_lgpd,
        u.data_aceite_lgpd,
        u.ativo,
        un.identificacao AS unidade_identificacao
    FROM Usuario u
    LEFT JOIN Unidade un ON un.id = u.unidade_id
    WHERE u.perfil = 'Morador'
    ORDER BY
        CASE WHEN u.termo_lgpd = 1 AND u.data_aceite_lgpd IS NOT NULL THEN 0 ELSE 1 END,
        u.nome ASC
";

$stmt = $conexao->query($sql);
$moradores = $stmt->fetchAll(PDO::FETCH_ASSOC);
$total = count($moradores);
$aceitos = count(array_filter($moradores, fn($m) => (int)($m['termo_lgpd'] ?? 0) === 1 && !empty($m['data_aceite_lgpd'])));
$pendentes = $total - $aceitos;
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LGPD dos Moradores - Koinon Service</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/estilo.css">
</head>
<body>
<nav class="navbar">
    <div class="container-fluid px-4">
        <a class="navbar-brand fw-bold text-decoration-none" href="dashboard.php">Koinon Service</a>
        <div class="d-flex align-items-center gap-2 koinon-nav-actions">
            <!-- Apenas sino e troca de tema nesta tela. -->
        </div>
    </div>
</nav>

<main class="container py-4">
    <div class="koinon-page-header mb-4">
        <a href="dashboard.php" class="btn btn-outline-secondary btn-sm mb-3">← Voltar ao Dashboard</a>
        <div class="koinon-premium-hero">
            <div class="d-flex justify-content-between align-items-start flex-wrap gap-3">
                <div>
                    <span class="badge rounded-pill bg-light text-dark mb-2">Privacidade</span>
                    <h1 class="h2 fw-bold mb-2">Aceites de LGPD dos moradores</h1>
                    <p class="mb-0 text-white-50">Acompanhe quem já aceitou o termo e a data/hora registrada no cadastro.</p>
                </div>
                <div class="text-end">
                    <div class="small text-white-50">Moradores</div>
                    <div class="display-6 fw-bold"><?= $total ?></div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-md-4"><div class="koinon-stat-card"><div class="small text-muted">Total de moradores</div><div class="h3 mb-0"><?= $total ?></div></div></div>
        <div class="col-md-4"><div class="koinon-stat-card"><div class="small text-muted">LGPD aceita</div><div class="h3 mb-0 text-success"><?= $aceitos ?></div></div></div>
        <div class="col-md-4"><div class="koinon-stat-card"><div class="small text-muted">Pendentes</div><div class="h3 mb-0 text-warning"><?= $pendentes ?></div></div></div>
    </div>

    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
            <strong>Registro individual</strong>
            <span class="small text-muted">Dados consultados diretamente da tabela Usuario</span>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Morador</th>
                            <th>CPF</th>
                            <th>E-mail</th>
                            <th>Unidade</th>
                            <th>Status LGPD</th>
                            <th>Data/hora do aceite</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if (!$moradores): ?>
                        <tr><td colspan="6" class="text-center text-muted py-4">Nenhum morador cadastrado.</td></tr>
                    <?php else: ?>
                        <?php foreach ($moradores as $morador): ?>
                            <?php $aceitou = (int)($morador['termo_lgpd'] ?? 0) === 1 && !empty($morador['data_aceite_lgpd']); ?>
                            <tr>
                                <td>
                                    <strong><?= htmlspecialchars($morador['nome'] ?? '') ?></strong>
                                    <div class="small text-muted"><?= htmlspecialchars($morador['perfil'] ?? 'Morador') ?></div>
                                </td>
                                <td><?= htmlspecialchars($morador['cpf'] ?? '—') ?></td>
                                <td><?= htmlspecialchars($morador['email'] ?? '—') ?></td>
                                <td><?= htmlspecialchars($morador['unidade_identificacao'] ?? 'Não vinculada') ?></td>
                                <td>
                                    <?php if ($aceitou): ?>
                                        <span class="badge text-bg-success">Aceito</span>
                                    <?php else: ?>
                                        <span class="badge text-bg-warning">Pendente</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?= $aceitou ? htmlspecialchars(date('d/m/Y H:i:s', strtotime($morador['data_aceite_lgpd']))) : 'Ainda não aceitou' ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="alert alert-info mt-4">
        <strong>Como o registro funciona:</strong> o aceite é gravado diretamente no cadastro do usuário, nos campos <code>termo_lgpd</code> e <code>data_aceite_lgpd</code>. Não é criada uma tabela adicional para isso.
    </div>
</main>
<script src="../assets/js/script.js"></script>
</body>
</html>
