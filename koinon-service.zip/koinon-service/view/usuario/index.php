<?php

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_once __DIR__ . "/../../controller/PermissaoController.php";
require_once __DIR__ . "/../../controller/UsuarioController.php";

PermissaoController::exigirAdministrador();

$controller = new UsuarioController();

$usuarios = $controller->listar();

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Usuários - Koinon Service</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <link rel="stylesheet" href="../../assets/css/estilo.css">

</head>

<body class="bg-light">

<div class="container mt-5">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>
            <h2>Usuários</h2>
            <p class="text-muted mb-0">
                Gerenciamento de usuários do condomínio
            </p>
        </div>

        <div>
            <a href="cadastrar.php" class="btn btn-primary">
                + Novo Usuário
            </a>

            <a
                href="/koinon-service/view/logout.php"
                class="btn btn-outline-danger"
            >
                Sair
            </a>
        </div>

    </div>

    <?php if (isset($_GET["sucesso"])): ?>

        <div class="alert alert-success">
            Operação realizada com sucesso!
        </div>

    <?php endif; ?>


    <?php if (isset($_GET["erro"])): ?>

        <div class="alert alert-danger">
            Ocorreu um erro ao realizar a operação.
        </div>

    <?php endif; ?>


    <div class="card shadow-sm">

        <div class="card-body">

            <div class="table-responsive">

                <table class="table table-bordered table-hover align-middle">

                    <thead class="table-dark">

                        <tr>
                            <th>Nome</th>
                            <th>CPF</th>
                            <th>E-mail</th>
                            <th>Perfil</th>
                            <th>Unidade</th>
                            <th>Status</th>
                            <th>Ações</th>
                        </tr>

                    </thead>

                    <tbody>

                    <?php if (empty($usuarios)): ?>

                        <tr>

                            <td colspan="7" class="text-center text-muted">

                                Nenhum usuário cadastrado.

                            </td>

                        </tr>

                    <?php else: ?>

                        <?php foreach ($usuarios as $usuario): ?>

                            <tr>

                                <td>
                                    <?= htmlspecialchars($usuario->getNome()) ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars($usuario->getCpf()) ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars($usuario->getEmail()) ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars($usuario->getPerfil()) ?>
                                </td>

                                <td>

                                    <?php

                                    $unidade =
                                        $usuario->getUnidadeIdentificacao();

                                    echo htmlspecialchars(
                                        $unidade ?: "Não vinculada"
                                    );

                                    ?>

                                </td>

                                <td>

                                    <?php if ($usuario->getAtivo()): ?>

                                        <span class="badge bg-success">
                                            Ativo
                                        </span>

                                    <?php else: ?>

                                        <span class="badge bg-danger">
                                            Inativo
                                        </span>

                                    <?php endif; ?>

                                </td>

                                <td>

                                    <a
                                        href="editar.php?id=<?= $usuario->getId() ?>"
                                        class="btn btn-sm btn-warning"
                                    >
                                        Editar
                                    </a>

                                    <?php if ($usuario->getAtivo()): ?>

                                        <a
                                            href="../../controller/UsuarioController.php?acao=excluir&id=<?= $usuario->getId() ?>"
                                            class="btn btn-sm btn-danger"
                                            onclick="return confirm('Deseja realmente desativar este usuário?');"
                                        >
                                            Desativar
                                        </a>

                                    <?php else: ?>

                                        <a
                                            href="../../controller/UsuarioController.php?acao=reativar&id=<?= $usuario->getId() ?>"
                                            class="btn btn-sm btn-success"
                                            onclick="return confirm('Deseja reativar este usuário?');"
                                        >
                                            Reativar
                                        </a>

                                    <?php endif; ?>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                    <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

</div>

<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js">
</script>
<script src="../../assets/js/script.js"></script>

</body>
</html>