<?php

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

header('Content-Type: application/json; charset=UTF-8');

require_once __DIR__ . '/../controller/PermissaoController.php';
require_once __DIR__ . '/../controller/NotificacaoController.php';

if (empty($_SESSION['usuario_id']) || empty($_SESSION['usuario_perfil'])) {
    echo json_encode(['total' => 0], JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    $controller = new NotificacaoController();
    $total = $controller->contarNaoLidas((int) $_SESSION['usuario_id']);

    echo json_encode([
        'total' => (int) $total,
        'perfil' => (string) $_SESSION['usuario_perfil']
    ], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    http_response_code(200);
    echo json_encode(['total' => 0], JSON_UNESCAPED_UNICODE);
}
