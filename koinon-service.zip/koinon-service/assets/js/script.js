/*
 * Koinon Service - interações globais
 * Identidade única: tema claro, marca centralizada, sino de notificações
 * em caixa própria e retorno contextual por perfil.
 */
(function () {
    'use strict';

    function getProjectRoot() {
        const script = document.currentScript || Array.from(document.scripts).find(s => (s.src || '').includes('/assets/js/script.js'));
        if (!script || !script.src) return '/koinon-service/';
        try {
            const url = new URL(script.src, window.location.href);
            return url.pathname.replace(/assets\/js\/script\.js.*$/, '');
        } catch (e) {
            return '/koinon-service/';
        }
    }

    function isMoradorPage() {
        return /\/view\/morador\//i.test(window.location.pathname);
    }

    function notificationTarget() {
        return isMoradorPage() ? 'view/morador/notificacoes.php' : 'view/notificacoes.php';
    }

    function resolveNotificationLink(link) {
        if (!link) return notificationTarget();
        if (/^https?:\/\//i.test(link) || link.startsWith('/')) return link;
        if (isMoradorPage()) return getProjectRoot() + 'view/morador/' + link.replace(/^view\/morador\//, '');
        if (link.startsWith('view/')) return getProjectRoot() + link;
        return getProjectRoot() + 'view/' + link;
    }

    function createNotificationBell() {
        if (document.querySelector('.koinon-notification-bell')) return;

        document.querySelectorAll('a[href*="notificacoes.php"]').forEach(existing => {
            existing.remove();
        });

        const link = document.createElement('a');
        link.href = '#';
        link.className = 'koinon-notification-bell';
        link.setAttribute('aria-label', 'Notificações');
        link.title = 'Notificações';
        link.setAttribute('aria-expanded', 'false');
        link.innerHTML = [
            '<span class="koinon-notification-icon" aria-hidden="true">🔔</span>',
            '<span class="koinon-notification-badge" hidden>0</span>',
            '<span class="visually-hidden">Notificações</span>'
        ].join('');

        link.addEventListener('click', function (event) {
            event.preventDefault();
            toggleNotificationPanel(link);
        });

        const nav = document.querySelector('.navbar');
        if (nav) {
            const container = nav.querySelector('.container-fluid, .container') || nav;
            let rightGroup = Array.from(container.children).find(el =>
                el !== link && el.classList && el.classList.contains('d-flex') &&
                (el.querySelector('a[href*="logout.php"]') || el.querySelector('.text-white, .fw-semibold'))
            );

            if (!rightGroup) {
                rightGroup = document.createElement('div');
                rightGroup.className = 'd-flex align-items-center gap-2 koinon-nav-actions';
                container.appendChild(rightGroup);
            } else {
                rightGroup.classList.add('koinon-nav-actions');
            }

            rightGroup.insertBefore(link, rightGroup.firstChild);
            return;
        }

        document.body.appendChild(link);
        link.classList.add('koinon-notification-floating');
    }

    function ensureNotificationPanel() {
        let panel = document.querySelector('.koinon-notification-panel');
        if (panel) return panel;

        panel = document.createElement('div');
        panel.className = 'koinon-notification-panel';
        panel.hidden = true;
        panel.innerHTML = [
            '<div class="koinon-notification-panel-head">',
                '<div><strong>Notificações</strong><div class="small text-muted" data-notification-summary>Carregando...</div></div>',
                '<button type="button" class="btn btn-sm btn-light" data-notification-close aria-label="Fechar">×</button>',
            '</div>',
            '<div class="koinon-notification-panel-body" data-notification-list>',
                '<div class="text-muted small p-3">Carregando notificações...</div>',
            '</div>',
            '<div class="koinon-notification-panel-foot">',
                '<button type="button" class="btn btn-sm btn-outline-primary" data-notification-read-all>Marcar todas como lidas</button>',
                '<a class="btn btn-sm btn-primary" href="' + getProjectRoot() + notificationTarget() + '">Ver todas</a>',
            '</div>'
        ].join('');
        document.body.appendChild(panel);

        panel.querySelector('[data-notification-close]').addEventListener('click', function () {
            closeNotificationPanel();
        });
        panel.querySelector('[data-notification-read-all]').addEventListener('click', async function () {
            await markAllNotificationsRead();
        });

        return panel;
    }

    function positionNotificationPanel(bell) {
        const panel = ensureNotificationPanel();
        const rect = bell.getBoundingClientRect();
        const width = Math.min(390, window.innerWidth - 20);
        panel.style.width = width + 'px';
        panel.style.top = Math.min(window.innerHeight - 20, rect.bottom + 10) + 'px';
        panel.style.right = Math.max(10, window.innerWidth - rect.right) + 'px';
        return panel;
    }

    async function loadNotificationPanel() {
        const panel = ensureNotificationPanel();
        const list = panel.querySelector('[data-notification-list]');
        const summary = panel.querySelector('[data-notification-summary]');
        list.innerHTML = '<div class="text-muted small p-3">Carregando notificações...</div>';

        try {
            const response = await fetch(getProjectRoot() + 'view/notificacao_popup.php', {
                credentials: 'same-origin',
                headers: { 'Accept': 'application/json' },
                cache: 'no-store'
            });
            if (!response.ok) throw new Error('Falha ao carregar notificações');
            const data = await response.json();
            const items = Array.isArray(data.items) ? data.items : [];
            summary.textContent = items.length ? (items.length + ' não lida(s)') : 'Nenhuma nova notificação';

            if (!items.length) {
                list.innerHTML = '<div class="text-muted small p-3">Você não possui novas notificações.</div>';
                return;
            }

            list.innerHTML = items.slice(0, 8).map(item => {
                const title = escapeHtml(item.titulo || 'Notificação');
                const message = escapeHtml(item.mensagem || '');
                const date = escapeHtml(item.created_at_formatado || item.created_at || '');
                const href = resolveNotificationLink(item.link || '');
                const id = Number(item.id || 0);
                return '<div class="koinon-notification-item" data-notification-id="' + id + '">' +
                    '<div class="koinon-notification-item-title">' + title + '</div>' +
                    '<div class="small text-muted mt-1">' + message + '</div>' +
                    '<div class="d-flex justify-content-between align-items-center mt-2 gap-2">' +
                        '<span class="small text-muted">' + date + '</span>' +
                        '<div class="d-flex gap-1">' +
                            '<button type="button" class="btn btn-sm btn-light" data-notification-mark="' + id + '">Lida</button>' +
                            (href ? '<a class="btn btn-sm btn-outline-primary" href="' + escapeAttr(href) + '">Abrir</a>' : '') +
                        '</div>' +
                    '</div>' +
                '</div>';
            }).join('');

            list.querySelectorAll('[data-notification-mark]').forEach(btn => {
                btn.addEventListener('click', async function () {
                    await markNotificationRead(Number(btn.dataset.notificationMark || 0));
                    await loadNotificationPanel();
                    refreshNotificationBadge();
                });
            });
        } catch (e) {
            summary.textContent = 'Não foi possível carregar';
            list.innerHTML = '<div class="alert alert-warning m-3 mb-0 small">Não foi possível carregar as notificações agora.</div>';
        }
    }

    async function markNotificationRead(id) {
        if (!id) return;
        try {
            await fetch(getProjectRoot() + 'view/notificacao_marcar_lida.php', {
                method: 'POST',
                credentials: 'same-origin',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'id=' + encodeURIComponent(id)
            });
        } catch (e) {}
    }

    async function markAllNotificationsRead() {
        try {
            await fetch(getProjectRoot() + 'view/notificacao_marcar_todas_lidas.php', {
                method: 'POST',
                credentials: 'same-origin'
            });
        } catch (e) {}
        await loadNotificationPanel();
        refreshNotificationBadge();
    }

    function toggleNotificationPanel(bell) {
        const panel = ensureNotificationPanel();
        if (!panel.hidden) {
            closeNotificationPanel();
            return;
        }
        positionNotificationPanel(bell);
        panel.hidden = false;
        bell.setAttribute('aria-expanded', 'true');
        loadNotificationPanel();
    }

    function closeNotificationPanel() {
        const panel = document.querySelector('.koinon-notification-panel');
        const bell = document.querySelector('.koinon-notification-bell');
        if (panel) panel.hidden = true;
        if (bell) bell.setAttribute('aria-expanded', 'false');
    }

    function escapeHtml(value) {
        return String(value).replace(/[&<>'"]/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[ch]));
    }

    function escapeAttr(value) { return escapeHtml(value); }

    async function refreshNotificationBadge() {
        const badge = document.querySelector('.koinon-notification-badge');
        if (!badge) return;
        try {
            const response = await fetch(getProjectRoot() + 'view/notificacao_badge.php', {
                credentials: 'same-origin',
                headers: { 'Accept': 'application/json' },
                cache: 'no-store'
            });
            if (!response.ok) return;
            const data = await response.json();
            const total = Number(data.total || 0);
            if (total > 0) {
                badge.textContent = total > 99 ? '99+' : String(total);
                badge.hidden = false;
            } else {
                badge.hidden = true;
            }
        } catch (e) {}
    }

    function isMainDashboardPage() {
        const path = window.location.pathname.toLowerCase();
        return /\/view\/dashboard\.php$/.test(path) || /\/view\/morador\/index\.php$/.test(path);
    }

    function standardizeNavbars() {
        const path = window.location.pathname.toLowerCase();
        const hideLegacyLogout = /\/view\/(encomenda|portaria)\/index\.php$/.test(path) || /\/view\/lgpd_registros\.php$/.test(path);

        document.querySelectorAll('.navbar').forEach(nav => {
            const container = nav.querySelector('.container-fluid, .container') || nav;
            const brands = container.querySelectorAll(':scope > .navbar-brand');
            if (brands.length > 1) brands.forEach((brand, index) => { if (index > 0) brand.remove(); });

            const brand = container.querySelector(':scope > .navbar-brand');
            if (brand) {
                brand.classList.add('koinon-navbar-brand-centered');
                brand.innerHTML = '<span>Koinon Service</span>';
                brand.setAttribute('aria-label', 'Koinon Service');
            }

            let groups = Array.from(container.querySelectorAll(':scope > .koinon-nav-actions'));
            let group = groups[0] || null;
            groups.slice(1).forEach(g => g.remove());

            // Preserve the existing user/logout group on authenticated dashboard pages.
            if (!group) {
                group = Array.from(container.children).find(el =>
                    el !== brand && el.classList && el.classList.contains('d-flex') &&
                    (el.querySelector('a[href*="logout.php"]') || el.querySelector('.fw-semibold, .text-white'))
                ) || null;
                if (group) group.classList.add('koinon-nav-actions');
            }

            if (group) {
                // O grupo permanece no fluxo normal do flexbox da navbar.
                // Nunca usar position:absolute aqui: isso fazia o grupo sair
                // do topo e aparecer no centro/fora da barra em algumas telas.
                if (group.parentElement !== container) container.appendChild(group);
                group.style.position = 'static';
                group.style.right = 'auto';
                group.style.left = 'auto';
                group.style.top = 'auto';
                group.style.bottom = 'auto';
                group.style.transform = 'none';
                group.style.marginLeft = 'auto';
                group.style.marginRight = '0';
                group.style.marginTop = '0';
                group.style.marginBottom = '0';
                group.style.padding = '0';
                group.style.width = 'auto';
                group.style.maxWidth = 'none';
                group.style.display = 'flex';
                group.style.alignItems = 'center';
                group.style.justifyContent = 'flex-end';
                group.style.flexDirection = 'row';
                group.style.flexWrap = 'nowrap';
                group.style.gap = '.625rem';
                group.style.zIndex = '20';
            }

            // Nas telas V10 selecionadas, o topo interno fica somente com sino e tema.
            if (hideLegacyLogout) {
                container.querySelectorAll('a[href*="logout.php"], .koinon-logout-btn').forEach(link => link.remove());
                container.querySelectorAll('.koinon-nav-actions .text-end, .koinon-nav-actions .koinon-user-name').forEach(el => el.remove());
            } else {
                container.querySelectorAll('a[href*="logout.php"]').forEach(link => link.classList.add('koinon-logout-btn'));
            }
        });
    }

    function setupContextualBackButton() {
        initTheme();
        initCpfMask();
        const path = window.location.pathname.toLowerCase();
        const isPublic = /\/(login|lgpd|esqueci_senha|redefinir_senha|acesso_negado)\.php$/.test(path);
        const isAction = /\/logout\.php$/.test(path);
        const isMorador = isMoradorPage();
        const rootPage = /\/(?:koinon-service\/)?$/.test(path) || (/\/index\.php$/.test(path) && !path.includes('/view/'));
        const dashboard = /\/view\/(dashboard|morador\/index)\.php$/.test(path);
        const profilePage = /\/view\//.test(path);
        if (profilePage && !rootPage && !dashboard && !isPublic && !isAction && !document.querySelector('.koinon-dashboard-back')) {
            const container = document.querySelector('.container-fluid, .container');
            if (container) {
                const wrapper = document.createElement('div');
                wrapper.className = 'koinon-dashboard-back';
                const href = isMorador ? getProjectRoot() + 'view/morador/index.php' : getProjectRoot() + 'view/dashboard.php';
                const label = isMorador ? '← Voltar à Área do Morador' : '← Voltar ao Dashboard';
                wrapper.innerHTML = '<a class="btn btn-outline-secondary btn-sm" href="' + href + '">' + label + '</a>';
                container.insertBefore(wrapper, container.firstChild);
            }
        }
    }



    function initCpfMask() {
        document.querySelectorAll('input[name="cpf"], input[data-cpf]').forEach(function(input){
            input.addEventListener('input', function(){
                let v = input.value.replace(/\D/g,'').slice(0,11);
                if(v.length > 9) v = v.replace(/(\d{3})(\d{3})(\d{3})(\d{1,2})/,'$1.$2.$3-$4');
                else if(v.length > 6) v = v.replace(/(\d{3})(\d{3})(\d{1,3})/,'$1.$2.$3');
                else if(v.length > 3) v = v.replace(/(\d{3})(\d{1,3})/,'$1.$2');
                input.value = v;
            });
        });
    }

    function initTheme() {
        const saved = localStorage.getItem('koinon-theme');
        const preferred = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches
            ? 'dark' : 'light';
        const theme = saved || preferred;
        document.documentElement.setAttribute('data-theme', theme);

        if (document.querySelector('.koinon-theme-toggle')) return;

        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'koinon-theme-toggle';
        button.title = theme === 'dark' ? 'Mudar para tema claro' : 'Mudar para tema escuro';
        button.setAttribute('aria-label', button.title);
        button.innerHTML = theme === 'dark' ? '☀️' : '🌙';

        function place() {
            const nav = document.querySelector('.navbar');
            if (nav) {
                const container = nav.querySelector('.container-fluid, .container') || nav;
                let group = container.querySelector('.koinon-nav-actions');
                if (!group) {
                    group = document.createElement('div');
                    group.className = 'koinon-nav-actions';
                    container.appendChild(group);
                }
                if (!group.contains(button)) {
                    const logout = group.querySelector('.koinon-logout-btn, a[href*="logout.php"]');
                    if (logout) group.insertBefore(button, logout);
                    else group.appendChild(button);
                }
            } else if (!document.body.contains(button)) {
                button.style.position = 'fixed';
                button.style.right = '18px';
                button.style.bottom = '18px';
                button.style.zIndex = '1500';
                document.body.appendChild(button);
            }
        }

        button.addEventListener('click', function () {
            const next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
            document.documentElement.setAttribute('data-theme', next);
            localStorage.setItem('koinon-theme', next);
            button.innerHTML = next === 'dark' ? '☀️' : '🌙';
            button.title = next === 'dark' ? 'Mudar para tema claro' : 'Mudar para tema escuro';
            button.setAttribute('aria-label', button.title);
        });

        place();
    }

    function init() {
        initTheme();
        const path = window.location.pathname.toLowerCase();
        const isPublic = /\/(login|lgpd|esqueci_senha|redefinir_senha|acesso_negado)\.php$/.test(path);
        const isAction = /\/logout\.php$/.test(path);

        // A página inicial pública (index.php fora de /view/) não deve exibir
        // controles de perfil. Já /view/morador/index.php e /view/dashboard.php
        // são áreas autenticadas e precisam do sino normalmente.
        const isPublicRoot = /\/(?:koinon-service\/)?$/.test(path) ||
            (/\/index\.php$/.test(path) && !path.includes('/view/'));
        const isProfileArea = /\/view\//.test(path) && !isPublic && !isAction;
        standardizeNavbars();
        if (isProfileArea && !isPublicRoot) {
            createNotificationBell();
            refreshNotificationBadge();
        }

        setupContextualBackButton();

        document.addEventListener('click', function (event) {
            const panel = document.querySelector('.koinon-notification-panel');
            const bell = document.querySelector('.koinon-notification-bell');
            if (panel && !panel.hidden && !panel.contains(event.target) && bell && !bell.contains(event.target)) {
                closeNotificationPanel();
            }
        });

        window.addEventListener('resize', function () {
            const panel = document.querySelector('.koinon-notification-panel');
            const bell = document.querySelector('.koinon-notification-bell');
            if (panel && !panel.hidden && bell) positionNotificationPanel(bell);
        });
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
})();
