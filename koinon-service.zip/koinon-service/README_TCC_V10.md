# Koinon Service — V10

## Entrega
Esta V10 consolida a base funcional da V9 e aplica os ajustes finais de navegação e organização solicitados para a apresentação do TCC.

## Ajustes da V10
- Encomendas: removido o botão **Sair** do cabeçalho interno; ficam sino e troca de tema.
- Portaria: removidos **Sair** e o bloco de identificação do topo; ficam sino e troca de tema.
- LGPD/registros: removidos **Dashboard** e **Sair** do cabeçalho; o retorno ao Dashboard continua no conteúdo.
- Área do Morador: removida a grade superior de atalhos duplicados.
- Área do Morador: o card-resumo de autorizações não repete o botão do módulo completo.
- Notificações: reforço de contraste no tema escuro.
- Indicador de vagas: reforço de contraste nos temas.
- Diagramas TCC regenerados de acordo com o escopo atual e as 16 tabelas do `database.sql`.
- Documentação acadêmica atualizada para a V10 em DOCX e PDF.

## Regras preservadas da V9
- Administrador e Síndico têm escopo de gestão por `PermissaoController::exigirGestao()`.
- Síndico pode operar o financeiro: cadastrar, editar, excluir, alterar status, registrar pagamento e atualizar vencimentos.
- Síndico e Administrador gerenciam locais de reserva.
- Morador consulta veículos/vagas e utiliza os fluxos de reservas, cobranças, encomendas, ocorrências, autorizações, publicações e documentos.
- O tema claro/escuro é persistido no navegador.

## Banco de dados
O projeto acompanha `database.sql`, com 16 tabelas:

`usuario`, `unidade`, `veiculo`, `cobranca`, `local_reserva`, `reserva`, `visitante`, `autorizacao_acesso`, `registro_acesso`, `encomenda`, `publicacao`, `enquete_opcao`, `interacao`, `notificacao`, `ocorrencia` e `documento`.

A V10 não exige uma migração estrutural adicional para os ajustes desta entrega.

## Documentação
- `DOCUMENTACAO_KOINON_V10.docx`
- `DOCUMENTACAO_KOINON_V10.pdf`
- `NOTAS_VERSAO_FINAL_V10.md`
- `docs_tcc/` com os cinco diagramas atualizados.

## Execução local
1. Instale XAMPP com Apache, PHP e MariaDB/MySQL.
2. Copie `koinon-service` para `C:\xampp\htdocs\`.
3. Inicie Apache e MySQL.
4. Importe `database.sql` no phpMyAdmin.
5. Confira a conexão em `model/dao/Conexao.php`.
6. Acesse `http://localhost/koinon-service/`.

## Validação realizada nesta entrega
Todos os 139 arquivos PHP do projeto passaram por verificação de sintaxe (`php -l`) sem erros. A estrutura do banco foi conferida e contém 16 comandos `CREATE TABLE`.
